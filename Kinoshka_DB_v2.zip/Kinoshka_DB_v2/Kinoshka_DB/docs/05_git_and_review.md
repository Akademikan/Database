# 5. Git-репозиторий и проверка одногруппником

## 5.1. Публикация на GitVerse или GitHub

```bash
git init
git add .
git commit -m "Kinoshka DB: схема БД (PostgreSQL, MySQL), JDBC-приложение, тесты, документация"
git branch -M main
git remote add origin https://gitverse.ru/<логин>/kinoshka-db.git    # или https://github.com/<логин>/kinoshka-db.git
git push -u origin main
```

Перед первым коммитом проверьте `git status`: файла `config/db.properties` с паролем в списке быть не должно (он в `.gitignore`).

## 5.2. Работа с ветками (что показать в отчёте)

Предлагаемая схема: `main` — рабочая версия, `develop` — интеграция, `feature/*` — отдельные задачи.

```bash
git checkout -b develop
git push -u origin develop

# задача: например, добавить отчёт или исправить замечание тестировщика
git checkout -b feature/occupancy-report develop
# ... правки ...
git add -A
git commit -m "Отчёт о заполняемости сеансов"
git push -u origin feature/occupancy-report
# на GitVerse/GitHub: Pull Request feature/occupancy-report -> develop, просмотр, слияние

git checkout develop
git pull
git checkout main
git merge --no-ff develop -m "Релиз 1.1"
git tag v1.1
git push origin main --tags
```

Для отчёта сделайте снимки: граф веток (`git log --oneline --graph --all`), Pull Request и список тегов.

Замечания тестировщика удобно оформлять как Issue и закрывать коммитом с текстом `fix #N`.

## 5.3. Инструкция для одногруппника-тестировщика

Задача — развернуть проект **только по README**, без помощи автора, и записать всё, что не получилось или было непонятно.

1. Клонировать репозиторий.
2. Установить JDK 21 и одну из СУБД: PostgreSQL или MySQL 8.
3. Выполнить разделы README «Развёртывание» 2–5.
4. Пройти сценарии Р1–Р12 из [04_test_plan.md](04_test_plan.md).
5. Выполнить `./mvnw test` (или `mvnw.cmd test`).
6. Выполнить `04_constraint_tests.sql` для своей СУБД и убедиться, что каждая команда даёт ошибку.

### Шаблон отчёта тестировщика (оформить как Issue)

```text
Тестировщик: ФИО, группа
ОС: …            JDK: …            СУБД и версия: …
Время на развёртывание: … мин

Шаг README | Получилось? | Что пошло не так / что было непонятно
-----------|-------------|--------------------------------------
2. База    |             |
3. Настр.  |             |
4. init-db |             |
5. Запуск  |             |

Сценарии Р1–Р12: пройдено N из 12, проблемы: …
mvnw test: … тестов, ошибок: …
Предложения: …
```

Исправления по замечаниям вносите в отдельной ветке `fix/...` через Pull Request. Ссылки на Issue и PR — в отчёт.
