#!/usr/bin/env bash
# Запуск Kinoshka DB в Linux/macOS.
#   ./run.sh              — графическое приложение
#   ./run.sh --init-db    — создать таблицы, триггеры и тестовые данные
#   ./run.sh --check      — проверить подключение к БД
# Первый запуск собирает проект (нужны JDK 21 и интернет для загрузки зависимостей).
set -e
cd "$(dirname "$0")"
JAR=target/kinoshka-db-1.0-all.jar
if [ ! -f "$JAR" ]; then
  echo "Сборка проекта..."
  chmod +x mvnw
  ./mvnw -q -DskipTests package
fi
if [ ! -f config/db.properties ]; then
  echo "Нет config/db.properties — скопируйте config/db.properties.example и укажите свои параметры."
  exit 1
fi
# UTF-8 для вывода в консоль: иначе в терминале с локалью POSIX вместо кириллицы будут «?»
exec java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -jar "$JAR" "$@"
