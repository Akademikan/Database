@echo off
rem Запуск Kinoshka DB в Windows.
rem   run.bat              - графическое приложение
rem   run.bat --init-db    - создать таблицы, триггеры и тестовые данные
rem   run.bat --check      - проверить подключение к БД
rem Первый запуск собирает проект (нужны JDK 21 и интернет для загрузки зависимостей).
rem Консоль Windows по умолчанию в кодировке CP866: переключаем на UTF-8, иначе кириллица в выводе искажается.
chcp 65001 >nul
cd /d "%~dp0"
set JAR=target\kinoshka-db-1.0-all.jar
if not exist "%JAR%" (
  echo Сборка проекта...
  call mvnw.cmd -q -DskipTests package || exit /b 1
)
if not exist config\db.properties (
  echo Нет config\db.properties - скопируйте config\db.properties.example и укажите свои параметры.
  exit /b 1
)
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -jar "%JAR%" %*
