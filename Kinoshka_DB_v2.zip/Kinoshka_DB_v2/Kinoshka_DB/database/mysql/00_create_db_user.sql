-- =====================================================================
-- Kinoshka DB. MySQL 8.0
-- 00_create_db_user.sql: выполняется ОДИН раз администратором (root).
-- Создаёт базу и пользователя приложения. Пароль поменяйте на свой
-- и укажите его в config/db.properties.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS kinoshka
    CHARACTER SET utf8mb4;

CREATE USER IF NOT EXISTS 'kino'@'localhost' IDENTIFIED BY 'kino';
CREATE USER IF NOT EXISTS 'kino'@'%'         IDENTIFIED BY 'kino';
GRANT ALL PRIVILEGES ON kinoshka.* TO 'kino'@'localhost';
GRANT ALL PRIVILEGES ON kinoshka.* TO 'kino'@'%';

-- В MySQL 8 по умолчанию включён двоичный журнал (binlog). Тогда пользователь
-- без привилегии SUPER не может создавать триггеры (ошибка 1419).
-- Разрешаем это (до перезапуска сервера; чтобы навсегда — добавьте
-- log_bin_trust_function_creators=1 в секцию [mysqld] файла my.ini / my.cnf).
SET GLOBAL log_bin_trust_function_creators = 1;
