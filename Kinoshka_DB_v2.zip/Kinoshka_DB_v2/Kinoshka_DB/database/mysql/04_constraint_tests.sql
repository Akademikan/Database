-- =====================================================================
-- Kinoshka DB. MySQL 8.0
-- 04_constraint_tests.sql: КАЖДАЯ команда ниже должна завершиться ошибкой.
-- Скрипт ничего не меняет в данных. Запуск целиком:
--   mysql -u kino -p --force kinoshka < database/mysql/04_constraint_tests.sql
-- (ключ --force у mysql — продолжать после ошибок; psql продолжает сам).
-- В DBeaver выполняйте команды по одной (Ctrl+Enter) и смотрите сообщение.
-- =====================================================================
-- 1. Дубликат названия фильма -> UNIQUE uq_movies_title
INSERT INTO movies (title, genre_id, duration_min) VALUES ('Интерстеллар', 1, 100);
-- 2. Длительность вне диапазона -> CHECK chk_movies_duration
INSERT INTO movies (title, genre_id, duration_min) VALUES ('Ошибка длительности', 1, -10);
-- 3. Недопустимый возрастной рейтинг -> CHECK chk_movies_age
INSERT INTO movies (title, genre_id, duration_min, age_rating) VALUES ('Ошибка рейтинга', 1, 90, 14);
-- 4. Несуществующий жанр -> FK fk_movies_genre
INSERT INTO movies (title, genre_id, duration_min) VALUES ('Ошибка жанра', 999, 90);
-- 5. Удаление жанра, у которого есть фильмы -> FK ON DELETE RESTRICT
DELETE FROM genres WHERE name = 'Фантастика';
-- 6. Одинаковое место в одном зале -> UNIQUE uq_seats_place
INSERT INTO seats (hall_id, row_no, seat_no) VALUES (1, 1, 1);
-- 7. Неположительная цена сеанса -> CHECK chk_sessions_price
INSERT INTO sessions (movie_id, hall_id, starts_at, base_price) VALUES (1, 1, '2030-01-01 09:00:00', -5);
-- 8. Два сеанса в одном зале в одно время -> UNIQUE uq_sessions_slot (или триггер KN002)
INSERT INTO sessions (movie_id, hall_id, starts_at, base_price)
SELECT 3, hall_id, starts_at, 300 FROM (SELECT * FROM sessions WHERE session_id = 1) AS s1;
-- 9. Сеанс начинается, пока предыдущий не закончился -> триггер KN002
INSERT INTO sessions (movie_id, hall_id, starts_at, base_price)
SELECT 3, hall_id, starts_at + INTERVAL 30 MINUTE, 300 FROM (SELECT * FROM sessions WHERE session_id = 1) AS s1;
-- 10. Неверный формат телефона -> CHECK chk_customers_phone
INSERT INTO customers (full_name, phone) VALUES ('Тест Телефон', '8 999 000-00-00');
-- 11. Повторный телефон -> UNIQUE uq_customers_phone
INSERT INTO customers (full_name, phone) VALUES ('Тест Дубль', '+79990000001');
-- 12. Неверный e-mail -> CHECK chk_customers_email
INSERT INTO customers (full_name, phone, email) VALUES ('Тест Почта', '+79990000099', 'no-at-sign');
-- 13. Бронирование несуществующего покупателя -> FK fk_bookings_customer
INSERT INTO bookings (customer_id) VALUES (999);
-- 14. Повторная продажа уже проданного места -> UNIQUE uq_tickets_sold
INSERT INTO tickets (booking_id, session_id, seat_id, price)
SELECT 1, session_id, seat_id, 100 FROM (SELECT * FROM tickets WHERE ticket_id = 1) AS t1;
-- 15. Место из другого зала -> триггер KN001
INSERT INTO tickets (booking_id, session_id, seat_id, price)
SELECT 1, s.session_id, (SELECT MIN(seat_id) FROM seats WHERE hall_id <> s.hall_id), 100
FROM sessions s WHERE s.session_id = 1;
-- 16. Неположительная цена билета -> CHECK chk_tickets_price
INSERT INTO tickets (booking_id, session_id, seat_id, price)
SELECT 1, s.session_id, (SELECT MAX(seat_id) FROM seats WHERE hall_id = s.hall_id), 0
FROM sessions s WHERE s.session_id = 1;
-- 17. Перенос сеанса с проданными билетами в другой зал -> триггер KN003
UPDATE sessions SET hall_id = 5 WHERE session_id = (SELECT x.id FROM (SELECT MIN(session_id) AS id FROM tickets) AS x);
-- 18. Удаление сеанса, на который проданы билеты -> FK fk_tickets_session RESTRICT
DELETE FROM sessions WHERE session_id = (SELECT MIN(session_id) FROM tickets);
