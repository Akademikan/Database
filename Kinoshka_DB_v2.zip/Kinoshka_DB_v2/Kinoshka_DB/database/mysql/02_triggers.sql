-- =====================================================================
-- Kinoshka DB. MySQL 8.0
-- 02_triggers.sql: бизнес-правила, которые нельзя выразить через CHECK/FK.
-- Коды ошибок (SQLSTATE) те же, что в версии для PostgreSQL:
--   KN001 — место принадлежит другому залу, чем сеанс;
--   KN002 — сеанс пересекается с другим сеансом в этом зале;
--   KN003 — нельзя перенести в другой зал сеанс, на который уже проданы билеты.
--
-- В MySQL у триггера одно событие, поэтому для INSERT и UPDATE —
-- отдельные триггеры, а общая логика вынесена в процедуры.
-- DELIMITER понимают mysql (консоль), MySQL Workbench и инсталлятор приложения.
-- В DBeaver выполняйте скрипт целиком командой «Execute SQL Script» (Alt+X).
-- =====================================================================

DROP PROCEDURE IF EXISTS check_ticket_seat_in_hall;
DROP PROCEDURE IF EXISTS check_session_no_overlap;

DELIMITER $$

-- Правило 1. Билет можно продать только на место из зала, где идёт сеанс.
CREATE PROCEDURE check_ticket_seat_in_hall(IN p_session_id INT, IN p_seat_id INT)
READS SQL DATA
BEGIN
    DECLARE v_session_hall INT DEFAULT NULL;
    DECLARE v_seat_hall    INT DEFAULT NULL;
    DECLARE v_msg          VARCHAR(255);
    SELECT hall_id INTO v_session_hall FROM sessions WHERE session_id = p_session_id;
    SELECT hall_id INTO v_seat_hall    FROM seats    WHERE seat_id    = p_seat_id;
    -- если сеанса/места нет, ошибку выдаст внешний ключ
    IF v_session_hall IS NOT NULL AND v_seat_hall IS NOT NULL
       AND v_session_hall <> v_seat_hall THEN
        SET v_msg = CONCAT('Место ', p_seat_id, ' находится в зале ', v_seat_hall,
                           ', а сеанс ', p_session_id, ' идёт в зале ', v_session_hall);
        SIGNAL SQLSTATE 'KN001' SET MESSAGE_TEXT = v_msg;
    END IF;
END$$

-- Правило 2. В одном зале сеансы не пересекаются с учётом длительности фильма
-- и перерыва на уборку: [начало; начало + длительность + перерыв).
CREATE PROCEDURE check_session_no_overlap(IN p_session_id INT, IN p_movie_id INT,
                                          IN p_hall_id INT, IN p_starts_at DATETIME)
READS SQL DATA
BEGIN
    DECLARE v_new_end  DATETIME;
    DECLARE v_conflict INT DEFAULT NULL;
    DECLARE v_lock     INT;
    DECLARE v_msg      VARCHAR(255);

    -- блокируем строку зала: параллельные транзакции, добавляющие сеансы
    -- в тот же зал, выполнят проверку по очереди (защита от гонки)
    SELECT hall_id INTO v_lock FROM halls WHERE hall_id = p_hall_id FOR UPDATE;

    SELECT p_starts_at + INTERVAL (m.duration_min + h.break_minutes) MINUTE
      INTO v_new_end
      FROM movies m, halls h
     WHERE m.movie_id = p_movie_id AND h.hall_id = p_hall_id;

    SELECT s.session_id INTO v_conflict
      FROM sessions s
      JOIN movies m ON m.movie_id = s.movie_id
      JOIN halls  h ON h.hall_id  = s.hall_id
     WHERE s.hall_id = p_hall_id
       AND s.session_id <> COALESCE(p_session_id, 0)
       AND s.starts_at < v_new_end
       AND p_starts_at < s.starts_at + INTERVAL (m.duration_min + h.break_minutes) MINUTE
     LIMIT 1;

    IF v_conflict IS NOT NULL THEN
        SET v_msg = CONCAT('Сеанс пересекается с сеансом ', v_conflict, ' в этом зале');
        SIGNAL SQLSTATE 'KN002' SET MESSAGE_TEXT = v_msg;
    END IF;
END$$

CREATE TRIGGER tickets_seat_in_hall_ins BEFORE INSERT ON tickets
FOR EACH ROW
BEGIN
    CALL check_ticket_seat_in_hall(NEW.session_id, NEW.seat_id);
END$$

CREATE TRIGGER tickets_seat_in_hall_upd BEFORE UPDATE ON tickets
FOR EACH ROW
BEGIN
    IF NEW.session_id <> OLD.session_id OR NEW.seat_id <> OLD.seat_id THEN
        CALL check_ticket_seat_in_hall(NEW.session_id, NEW.seat_id);
    END IF;
END$$

-- В BEFORE INSERT значение AUTO_INCREMENT ещё не известно (NEW.session_id = 0),
-- поэтому сравнение «не с самим собой» не мешает: существующих строк с id 0 нет.
CREATE TRIGGER sessions_no_overlap_ins BEFORE INSERT ON sessions
FOR EACH ROW
BEGIN
    CALL check_session_no_overlap(NEW.session_id, NEW.movie_id, NEW.hall_id, NEW.starts_at);
END$$

CREATE TRIGGER sessions_no_overlap_upd BEFORE UPDATE ON sessions
FOR EACH ROW
BEGIN
    IF NEW.hall_id <> OLD.hall_id
       AND EXISTS (SELECT 1 FROM tickets WHERE session_id = OLD.session_id) THEN
        SIGNAL SQLSTATE 'KN003' SET MESSAGE_TEXT = 'На сеанс уже проданы билеты, менять зал нельзя';
    END IF;
    IF NEW.movie_id <> OLD.movie_id OR NEW.hall_id <> OLD.hall_id OR NEW.starts_at <> OLD.starts_at THEN
        CALL check_session_no_overlap(OLD.session_id, NEW.movie_id, NEW.hall_id, NEW.starts_at);
    END IF;
END$$

DELIMITER ;
