-- =====================================================================
-- Kinoshka DB. MySQL 8.0.16+ (CHECK-ограничения работают начиная с 8.0.16)
-- 01_schema.sql: таблицы, ключи, ограничения, индексы.
-- Скрипт повторяемый: удаляет и заново создаёт все объекты.
-- =====================================================================

-- Таблицы удаляются в порядке, обратном зависимостям (триггеры удаляются вместе с таблицами)
DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS seats;
DROP TABLE IF EXISTS halls;
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS genres;

-- Справочник жанров
CREATE TABLE genres (
    genre_id  INT NOT NULL AUTO_INCREMENT,
    name      VARCHAR(60) NOT NULL,
    CONSTRAINT pk_genres      PRIMARY KEY (genre_id),
    CONSTRAINT uq_genres_name UNIQUE (name),
    CONSTRAINT chk_genres_name CHECK (CHAR_LENGTH(TRIM(name)) > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Фильмы
CREATE TABLE movies (
    movie_id      INT NOT NULL AUTO_INCREMENT,
    title         VARCHAR(200) NOT NULL,
    genre_id      INT          NOT NULL,
    duration_min  SMALLINT     NOT NULL,
    age_rating    SMALLINT     NOT NULL DEFAULT 0,
    poster_path   VARCHAR(255) NOT NULL DEFAULT '/com/example/kinoshka/posters/default.png',
    CONSTRAINT pk_movies        PRIMARY KEY (movie_id),
    CONSTRAINT uq_movies_title  UNIQUE (title),
    CONSTRAINT fk_movies_genre  FOREIGN KEY (genre_id) REFERENCES genres (genre_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_movies_title CHECK (CHAR_LENGTH(TRIM(title)) > 0),
    CONSTRAINT chk_movies_duration CHECK (duration_min BETWEEN 1 AND 600),
    CONSTRAINT chk_movies_age   CHECK (age_rating IN (0, 6, 12, 16, 18))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Кинозалы. Схема зала задаётся набором мест (таблица seats), поэтому
-- количество рядов/мест здесь не хранится: это было бы производными данными.
CREATE TABLE halls (
    hall_id        INT NOT NULL AUTO_INCREMENT,
    name           VARCHAR(60) NOT NULL,
    break_minutes  SMALLINT    NOT NULL DEFAULT 15,   -- перерыв на уборку между сеансами
    CONSTRAINT pk_halls       PRIMARY KEY (hall_id),
    CONSTRAINT uq_halls_name  UNIQUE (name),
    CONSTRAINT chk_halls_name CHECK (CHAR_LENGTH(TRIM(name)) > 0),
    CONSTRAINT chk_halls_break CHECK (break_minutes BETWEEN 0 AND 120)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Физические места в зале
CREATE TABLE seats (
    seat_id  INT NOT NULL AUTO_INCREMENT,
    hall_id  INT      NOT NULL,
    row_no   SMALLINT NOT NULL,
    seat_no  SMALLINT NOT NULL,
    CONSTRAINT pk_seats       PRIMARY KEY (seat_id),
    CONSTRAINT uq_seats_place UNIQUE (hall_id, row_no, seat_no),
    CONSTRAINT fk_seats_hall  FOREIGN KEY (hall_id) REFERENCES halls (hall_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_seats_row  CHECK (row_no  BETWEEN 1 AND 50),
    CONSTRAINT chk_seats_no   CHECK (seat_no BETWEEN 1 AND 60)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Сеансы. Дата и время начала хранятся одним значением TIMESTAMP:
-- так проще сравнивать интервалы показа.
CREATE TABLE sessions (
    session_id  INT NOT NULL AUTO_INCREMENT,
    movie_id    INT          NOT NULL,
    hall_id     INT          NOT NULL,
    starts_at   DATETIME    NOT NULL,
    base_price  DECIMAL(8,2) NOT NULL,
    CONSTRAINT pk_sessions       PRIMARY KEY (session_id),
    CONSTRAINT uq_sessions_slot  UNIQUE (hall_id, starts_at),
    CONSTRAINT fk_sessions_movie FOREIGN KEY (movie_id) REFERENCES movies (movie_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_sessions_hall  FOREIGN KEY (hall_id) REFERENCES halls (hall_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_sessions_price CHECK (base_price > 0 AND base_price <= 10000)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Покупатели. Телефон — естественный ключ покупателя.
CREATE TABLE customers (
    customer_id  INT NOT NULL AUTO_INCREMENT,
    full_name    VARCHAR(150) NOT NULL,
    phone        VARCHAR(16)  NOT NULL,
    email        VARCHAR(100),
    CONSTRAINT pk_customers       PRIMARY KEY (customer_id),
    CONSTRAINT uq_customers_phone UNIQUE (phone),
    CONSTRAINT uq_customers_email UNIQUE (email),
    CONSTRAINT chk_customers_name  CHECK (CHAR_LENGTH(TRIM(full_name)) > 0),
    CONSTRAINT chk_customers_phone CHECK (REGEXP_LIKE(phone, '^[+][0-9]{11,15}$')),
    CONSTRAINT chk_customers_email CHECK (email IS NULL OR email LIKE '_%@_%._%')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Бронирование (заказ): один покупатель, один момент оформления, 1..N билетов
CREATE TABLE bookings (
    booking_id   INT NOT NULL AUTO_INCREMENT,
    customer_id  INT          NOT NULL,
    created_at   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_bookings          PRIMARY KEY (booking_id),
    CONSTRAINT fk_bookings_customer FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Билеты: конкретное место на конкретный сеанс в рамках бронирования.
-- price хранится, т.к. это цена на момент продажи (базовая цена сеанса может измениться).
CREATE TABLE tickets (
    ticket_id   INT NOT NULL AUTO_INCREMENT,
    booking_id  INT          NOT NULL,
    session_id  INT          NOT NULL,
    seat_id     INT          NOT NULL,
    price       DECIMAL(8,2) NOT NULL,
    CONSTRAINT pk_tickets          PRIMARY KEY (ticket_id),
    CONSTRAINT uq_tickets_sold     UNIQUE (session_id, seat_id),   -- место не продаётся дважды
    CONSTRAINT fk_tickets_booking  FOREIGN KEY (booking_id) REFERENCES bookings (booking_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_tickets_session  FOREIGN KEY (session_id) REFERENCES sessions (session_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_tickets_seat     FOREIGN KEY (seat_id) REFERENCES seats (seat_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_tickets_price   CHECK (price > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Индексы: MySQL (InnoDB) сам создаёт индексы для внешних ключей,
-- поэтому добавляем только индекс под выборку сеансов фильма по времени.
CREATE INDEX ix_sessions_movie ON sessions (movie_id, starts_at);
