-- =====================================================================
-- Kinoshka DB. MySQL 8.0
-- 03_data.sql: тестовые данные (не менее 5 строк в каждой таблице).
-- Те же данные, что и в версии для PostgreSQL. Вместо generate_series
-- используются рекурсивные CTE (MySQL 8.0+).
-- Даты сеансов считаются от CURRENT_DATE.
-- =====================================================================

INSERT INTO genres (name) VALUES
('Фантастика'), ('Триллер'), ('Мультфильм'), ('Комедия'), ('Ужасы'), ('Мелодрама');

INSERT INTO movies (title, genre_id, duration_min, age_rating, poster_path)
SELECT v.title, g.genre_id, v.dur, v.age, v.poster
FROM (
  SELECT 1 AS ord, 'Интерстеллар' AS title, 'Фантастика' AS genre, 169 AS dur, 12 AS age, '/com/example/kinoshka/posters/interstellar.png' AS poster
  UNION ALL SELECT 2, 'Начало',                    'Триллер',    148, 12, '/com/example/kinoshka/posters/inception.png'
  UNION ALL SELECT 3, 'Кунг-фу Панда',             'Мультфильм',  95,  0, '/com/example/kinoshka/posters/kungfu_panda.png'
  UNION ALL SELECT 4, 'Наследник',                 'Комедия',    105, 16, '/com/example/kinoshka/posters/heir.png'
  UNION ALL SELECT 5, 'Новая тёща',                'Комедия',     96, 12, '/com/example/kinoshka/posters/new_mother_in_law.png'
  UNION ALL SELECT 6, 'К себе нежно',              'Мелодрама',  108, 16, '/com/example/kinoshka/posters/be_gentle_to_yourself.png'
  UNION ALL SELECT 7, 'Горничная',                 'Триллер',    132, 18, '/com/example/kinoshka/posters/maid.png'
  UNION ALL SELECT 8, 'Два, три, призрак, приди!', 'Ужасы',       94, 18, '/com/example/kinoshka/posters/two_three_ghost_come.png'
) AS v
JOIN genres g ON g.name = v.genre
ORDER BY v.ord;   -- порядок вставки определяет movie_id (как в PostgreSQL-версии)

INSERT INTO halls (name, break_minutes) VALUES
('Зал 1', 15), ('Зал 2', 15), ('Зал 3', 15), ('VIP-зал', 20), ('Малый зал', 10);

-- Места: прямоугольная сетка для каждого зала
INSERT INTO seats (hall_id, row_no, seat_no)
WITH RECURSIVE nums (n) AS (SELECT 1 UNION ALL SELECT n + 1 FROM nums WHERE n < 10),
dims AS (
  SELECT 'Зал 1' AS hall, 8 AS rows_cnt, 10 AS per_row
  UNION ALL SELECT 'Зал 2', 6, 8
  UNION ALL SELECT 'Зал 3', 5, 8
  UNION ALL SELECT 'VIP-зал', 3, 6
  UNION ALL SELECT 'Малый зал', 4, 6
)
SELECT h.hall_id, r.n, s.n
FROM dims d
JOIN halls h ON h.name = d.hall
JOIN nums r ON r.n <= d.rows_cnt
JOIN nums s ON s.n <= d.per_row
ORDER BY h.hall_id, r.n, s.n;

-- В последнем ряду Зала 1 первые два места убраны (площадка для кресел-колясок)
DELETE FROM seats
WHERE hall_id = (SELECT hall_id FROM (SELECT hall_id FROM halls WHERE name = 'Зал 1') AS x)
  AND row_no = 8 AND seat_no IN (1, 2);

-- Расписание на 7 дней: в каждом зале 4 сеанса в день с шагом 3,5 часа.
-- Сначала строим расписание во временной таблице: триггер проверки пересечений
-- блокирует строку зала (SELECT ... FOR UPDATE), а MySQL запрещает триггеру
-- обращаться к таблице, которую читает сам INSERT ... SELECT (ошибка 1442).
DROP TEMPORARY TABLE IF EXISTS tmp_schedule;
CREATE TEMPORARY TABLE tmp_schedule
WITH RECURSIVE days (d) AS (SELECT 0 UNION ALL SELECT d + 1 FROM days WHERE d < 6),
slots AS (
  SELECT 0 AS slot, TIME '10:00:00' AS slot_time, 250 AS price
  UNION ALL SELECT 1, TIME '13:30:00', 300
  UNION ALL SELECT 2, TIME '17:00:00', 350
  UNION ALL SELECT 3, TIME '20:30:00', 400
),
numbered AS (SELECT movie_id, ROW_NUMBER() OVER (ORDER BY movie_id) - 1 AS rn FROM movies)
SELECT nm.movie_id, h.hall_id,
       TIMESTAMP(CURRENT_DATE + INTERVAL dy.d DAY, sl.slot_time) AS starts_at,
       sl.price + CASE WHEN h.name = 'VIP-зал' THEN 200 ELSE 0 END AS base_price
FROM halls h
CROSS JOIN days dy
CROSS JOIN slots sl
JOIN numbered nm ON nm.rn = (h.hall_id + dy.d + sl.slot) % 8;

INSERT INTO sessions (movie_id, hall_id, starts_at, base_price)
SELECT movie_id, hall_id, starts_at, base_price FROM tmp_schedule ORDER BY hall_id, starts_at;
DROP TEMPORARY TABLE tmp_schedule;

INSERT INTO customers (full_name, phone, email) VALUES
('Иван Петров',    '+79990000001', 'ivan.petrov@mail.ru'),
('Анна Смирнова',  '+79990000002', 'anna.smirnova@yandex.ru'),
('Павел Иванов',   '+79990000003', NULL),
('Мария Соколова', '+79990000004', 'm.sokolova@gmail.com'),
('Олег Кузнецов',  '+79990000005', NULL),
('Елена Волкова',  '+79990000006', 'volkova@spbstu.ru');

INSERT INTO bookings (customer_id, created_at)
SELECT customer_id, NOW() - INTERVAL customer_id HOUR FROM customers ORDER BY customer_id;

-- Билеты: ряды 1–2 — 90 % базовой цены, последний ряд зала — 115 %, остальные — 100 %
INSERT INTO tickets (booking_id, session_id, seat_id, price)
WITH chosen AS (
    SELECT b.booking_id, s.session_id, s.hall_id, s.base_price,
           ROW_NUMBER() OVER (PARTITION BY b.booking_id ORDER BY s.starts_at, s.hall_id) AS rn
    FROM bookings b
    JOIN sessions s ON s.starts_at >= CURRENT_DATE + INTERVAL 1 DAY
), pick AS (
    SELECT booking_id, session_id, hall_id, base_price FROM chosen WHERE rn = booking_id
), places AS (
    SELECT p.booking_id, p.session_id, p.base_price, st.seat_id, st.row_no, st.seat_no,
           MAX(st.row_no) OVER (PARTITION BY st.hall_id) AS last_row
    FROM pick p
    JOIN seats st ON st.hall_id = p.hall_id
)
SELECT booking_id, session_id, seat_id,
       ROUND(base_price * CASE WHEN row_no <= 2 THEN 0.90
                               WHEN row_no = last_row THEN 1.15
                               ELSE 1.00 END, 2)
FROM places
WHERE (row_no = 1 AND seat_no IN (1, 2))
   OR (row_no = last_row AND seat_no = 3)
ORDER BY booking_id, row_no, seat_no;
