-- =====================================================================
-- Kinoshka DB. PostgreSQL
-- 00_create_db_user.sql: выполняется ОДИН раз администратором (postgres),
-- например: psql -U postgres -f database/postgresql/00_create_db_user.sql
-- Пароль поменяйте на свой и укажите его в config/db.properties.
-- =====================================================================
CREATE ROLE kino LOGIN PASSWORD 'kino';
CREATE DATABASE kinoshka OWNER kino ENCODING 'UTF8' TEMPLATE template0;
