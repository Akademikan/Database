-- =====================================================================
-- Kinoshka DB. PostgreSQL
-- 03_data.sql: тестовые данные (не менее 5 строк в каждой таблице).
-- Даты сеансов считаются от CURRENT_DATE, поэтому в любой день запуска
-- в базе есть расписание на ближайшую неделю.
-- =====================================================================

INSERT INTO genres (name) VALUES
('Фантастика'), ('Триллер'), ('Мультфильм'), ('Комедия'), ('Ужасы'), ('Мелодрама');

INSERT INTO movies (title, genre_id, duration_min, age_rating, poster_path)
SELECT v.title, g.genre_id, v.dur, v.age, v.poster
FROM (VALUES
  (1, 'Интерстеллар',              'Фантастика', 169, 12, '/com/example/kinoshka/posters/interstellar.png'),
  (2, 'Начало',                    'Триллер',    148, 12, '/com/example/kinoshka/posters/inception.png'),
  (3, 'Кунг-фу Панда',             'Мультфильм',  95,  0, '/com/example/kinoshka/posters/kungfu_panda.png'),
  (4, 'Наследник',                 'Комедия',    105, 16, '/com/example/kinoshka/posters/heir.png'),
  (5, 'Новая тёща',                'Комедия',     96, 12, '/com/example/kinoshka/posters/new_mother_in_law.png'),
  (6, 'К себе нежно',              'Мелодрама',  108, 16, '/com/example/kinoshka/posters/be_gentle_to_yourself.png'),
  (7, 'Горничная',                 'Триллер',    132, 18, '/com/example/kinoshka/posters/maid.png'),
  (8, 'Два, три, призрак, приди!', 'Ужасы',       94, 18, '/com/example/kinoshka/posters/two_three_ghost_come.png')
) AS v(ord, title, genre, dur, age, poster)
JOIN genres g ON g.name = v.genre
ORDER BY v.ord;

INSERT INTO halls (name, break_minutes) VALUES
('Зал 1', 15), ('Зал 2', 15), ('Зал 3', 15), ('VIP-зал', 20), ('Малый зал', 10);

-- Места: прямоугольная сетка рядов и мест для каждого зала ...
INSERT INTO seats (hall_id, row_no, seat_no)
SELECT h.hall_id, r, n
FROM (VALUES ('Зал 1', 8, 10), ('Зал 2', 6, 8), ('Зал 3', 5, 8),
             ('VIP-зал', 3, 6), ('Малый зал', 4, 6)) AS d(hall, rows_cnt, per_row)
JOIN halls h ON h.name = d.hall
CROSS JOIN LATERAL generate_series(1, d.rows_cnt) AS r
CROSS JOIN LATERAL generate_series(1, d.per_row)  AS n;
-- ... но схема зала не обязана быть прямоугольной: в последнем ряду Зала 1
-- первые два места убраны (площадка для кресел-колясок)
DELETE FROM seats
WHERE hall_id = (SELECT hall_id FROM halls WHERE name = 'Зал 1') AND row_no = 8 AND seat_no IN (1, 2);

-- Расписание на 7 дней: в каждом зале 4 сеанса в день с шагом 3,5 часа.
-- Самый длинный фильм (169 мин) + перерыв (20 мин) меньше шага, поэтому
-- сеансы не пересекаются и проходят проверку триггером.
INSERT INTO sessions (movie_id, hall_id, starts_at, base_price)
SELECT m.movie_id, h.hall_id,
       CURRENT_DATE + d + t.slot_time,
       t.price + CASE WHEN h.name = 'VIP-зал' THEN 200 ELSE 0 END
FROM halls h
CROSS JOIN generate_series(0, 6) AS d
CROSS JOIN (VALUES (0, TIME '10:00', 250), (1, TIME '13:30', 300),
                   (2, TIME '17:00', 350), (3, TIME '20:30', 400)) AS t(slot, slot_time, price)
JOIN movies m ON m.movie_id = (SELECT movie_id FROM movies ORDER BY movie_id
                               OFFSET ((h.hall_id + d + t.slot) % 8) LIMIT 1);

INSERT INTO customers (full_name, phone, email) VALUES
('Иван Петров',    '+79990000001', 'ivan.petrov@mail.ru'),
('Анна Смирнова',  '+79990000002', 'anna.smirnova@yandex.ru'),
('Павел Иванов',   '+79990000003', NULL),
('Мария Соколова', '+79990000004', 'm.sokolova@gmail.com'),
('Олег Кузнецов',  '+79990000005', NULL),
('Елена Волкова',  '+79990000006', 'volkova@spbstu.ru');

INSERT INTO bookings (customer_id, created_at)
SELECT customer_id, CURRENT_TIMESTAMP(0) - (customer_id || ' hours')::interval
FROM customers;

-- Билеты: бронирование k покупает места в одном из ближайших сеансов.
-- Цена считается по тем же правилам, что и в приложении:
-- ряды 1–2 — 90 % базовой цены, последний ряд зала — 115 %, остальные — 100 %.
WITH chosen AS (
    SELECT b.booking_id, s.session_id, s.hall_id, s.base_price,
           ROW_NUMBER() OVER (PARTITION BY b.booking_id ORDER BY s.starts_at, s.hall_id) AS rn
    FROM bookings b
    JOIN sessions s ON s.starts_at >= CURRENT_DATE + 1
), pick AS (
    SELECT booking_id, session_id, hall_id, base_price
    FROM chosen WHERE rn = booking_id            -- у каждого бронирования свой сеанс
), places AS (
    SELECT p.booking_id, p.session_id, p.base_price, st.seat_id, st.row_no, st.seat_no,
           MAX(st.row_no) OVER (PARTITION BY st.hall_id) AS last_row
    FROM pick p
    JOIN seats st ON st.hall_id = p.hall_id
)
INSERT INTO tickets (booking_id, session_id, seat_id, price)
SELECT booking_id, session_id, seat_id,
       ROUND(base_price * CASE WHEN row_no <= 2 THEN 0.90
                               WHEN row_no = last_row THEN 1.15
                               ELSE 1.00 END, 2)
FROM places
WHERE (row_no = 1 AND seat_no IN (1, 2))          -- ряд 1: по 2 места
   OR (row_no = last_row AND seat_no = 3);        -- последний ряд: 1 место
