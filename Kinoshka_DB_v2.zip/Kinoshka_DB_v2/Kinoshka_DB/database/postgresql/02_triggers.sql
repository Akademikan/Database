-- =====================================================================
-- Kinoshka DB. PostgreSQL
-- 02_triggers.sql: бизнес-правила, которые нельзя выразить через CHECK/FK.
-- Коды ошибок (SQLSTATE) одинаковы для PostgreSQL и MySQL — приложение
-- переводит их в понятные сообщения:
--   KN001 — место принадлежит другому залу, чем сеанс;
--   KN002 — сеанс пересекается с другим сеансом в этом зале;
--   KN003 — нельзя перенести в другой зал сеанс, на который уже проданы билеты.
-- =====================================================================

-- Правило 1. Билет можно продать только на место из зала, где идёт сеанс.
CREATE OR REPLACE FUNCTION trg_ticket_seat_in_hall() RETURNS trigger AS $$
DECLARE
    v_session_hall INTEGER;
    v_seat_hall    INTEGER;
BEGIN
    SELECT hall_id INTO v_session_hall FROM sessions WHERE session_id = NEW.session_id;
    SELECT hall_id INTO v_seat_hall    FROM seats    WHERE seat_id    = NEW.seat_id;
    -- если сеанса/места нет, ошибку выдаст внешний ключ
    IF v_session_hall IS NOT NULL AND v_seat_hall IS NOT NULL
       AND v_session_hall <> v_seat_hall THEN
        RAISE EXCEPTION 'Место % находится в зале %, а сеанс % идёт в зале %',
              NEW.seat_id, v_seat_hall, NEW.session_id, v_session_hall
              USING ERRCODE = 'KN001';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tickets_seat_in_hall
    BEFORE INSERT OR UPDATE OF session_id, seat_id ON tickets
    FOR EACH ROW EXECUTE FUNCTION trg_ticket_seat_in_hall();

-- Правило 2. В одном зале сеансы не пересекаются с учётом длительности фильма
-- и перерыва на уборку зала: [начало; начало + длительность + перерыв).
CREATE OR REPLACE FUNCTION trg_session_no_overlap() RETURNS trigger AS $$
DECLARE
    v_new_end   TIMESTAMP;
    v_conflict  INTEGER;
BEGIN
    IF TG_OP = 'UPDATE' AND NEW.hall_id <> OLD.hall_id
       AND EXISTS (SELECT 1 FROM tickets WHERE session_id = OLD.session_id) THEN
        RAISE EXCEPTION 'На сеанс % уже проданы билеты, менять зал нельзя', OLD.session_id
              USING ERRCODE = 'KN003';
    END IF;

    -- блокируем строку зала: параллельные транзакции, добавляющие сеансы
    -- в тот же зал, выполнят проверку по очереди (защита от гонки)
    PERFORM 1 FROM halls WHERE hall_id = NEW.hall_id FOR UPDATE;

    SELECT NEW.starts_at + make_interval(mins => m.duration_min + h.break_minutes)
      INTO v_new_end
      FROM movies m, halls h
     WHERE m.movie_id = NEW.movie_id AND h.hall_id = NEW.hall_id;

    SELECT s.session_id INTO v_conflict
      FROM sessions s
      JOIN movies m ON m.movie_id = s.movie_id
      JOIN halls  h ON h.hall_id  = s.hall_id
     WHERE s.hall_id = NEW.hall_id
       AND s.session_id <> NEW.session_id
       AND s.starts_at < v_new_end
       AND NEW.starts_at < s.starts_at + make_interval(mins => m.duration_min + h.break_minutes)
     LIMIT 1;

    IF v_conflict IS NOT NULL THEN
        RAISE EXCEPTION 'Сеанс пересекается с сеансом % в этом зале', v_conflict
              USING ERRCODE = 'KN002';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sessions_no_overlap
    BEFORE INSERT OR UPDATE OF movie_id, hall_id, starts_at ON sessions
    FOR EACH ROW EXECUTE FUNCTION trg_session_no_overlap();
