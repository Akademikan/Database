package com.example.kinoshka.service;

/** Ошибка, понятная пользователю: нарушение бизнес-правила или неверный ввод. */
public class BookingException extends Exception {
    private static final long serialVersionUID = 1L;
    public BookingException(String message) { super(message); }
    public BookingException(String message, Throwable cause) { super(message, cause); }
}
