package com.example.kinoshka.ui;

import com.example.kinoshka.model.Customer;
import com.example.kinoshka.model.Movie;
import com.example.kinoshka.model.Seat;
import com.example.kinoshka.model.Session;
import com.example.kinoshka.model.Ticket;
import com.example.kinoshka.repo.BookingRepository;
import com.example.kinoshka.repo.CatalogRepository;
import com.example.kinoshka.service.BookingException;
import com.example.kinoshka.service.PriceCalculator;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Вкладка «Касса»: выбор фильма, сеанса и мест, оформление бронирования. */
class CashierTab extends Tab {
    private final CatalogRepository catalog;
    private final BookingRepository bookings;

    private final DatePicker dayPicker = Ui.datePicker(LocalDate.now());
    private final ListView<Movie> movieList = new ListView<>();
    private final ListView<Session> sessionList = new ListView<>();
    private final ImageView poster = new ImageView();
    private final Label movieInfo = new Label("Выберите фильм");
    private final GridPane seatGrid = new GridPane();
    private final Label hallCaption = new Label();
    private final TextField phoneField = new TextField();
    private final TextField nameField = new TextField();
    private final TextField emailField = new TextField();
    private final Label customerHint = new Label();
    private final ListView<String> selectedList = new ListView<>();
    private final Label totalLabel = new Label("Итого: 0 ₽");
    private final TextArea resultArea = new TextArea();

    /** Выбранные места: id места → место (порядок выбора сохраняется). */
    private final Map<Integer, Seat> selected = new LinkedHashMap<>();

    CashierTab(CatalogRepository catalog, BookingRepository bookings) {
        super("Касса");
        this.catalog = catalog;
        this.bookings = bookings;
        setClosable(false);
        setContent(build());
    }

    private Pane build() {
        // --- левая колонка: дата, фильмы, постер
        dayPicker.setOnAction(e -> loadSessions());
        movieList.setPrefWidth(250);
        movieList.getSelectionModel().selectedItemProperty().addListener((o, a, m) -> { showMovie(m); loadSessions(); });
        poster.setFitWidth(150);
        poster.setFitHeight(220);
        poster.setPreserveRatio(true);
        movieInfo.setWrapText(true);
        VBox left = new VBox(8, Ui.header("Дата"), dayPicker, Ui.header("Фильмы"), movieList,
                new HBox(10, poster, movieInfo));
        VBox.setVgrow(movieList, Priority.ALWAYS);
        left.setPrefWidth(270);

        // --- центр: сеансы и схема зала
        sessionList.setPrefHeight(150);
        sessionList.getSelectionModel().selectedItemProperty().addListener((o, a, s) -> drawSeats());
        seatGrid.setHgap(4);
        seatGrid.setVgap(4);
        seatGrid.setAlignment(Pos.CENTER);
        Label screen = new Label("ЭКРАН");
        screen.getStyleClass().add("screen");
        screen.setMaxWidth(Double.MAX_VALUE);
        HBox legend = new HBox(12, legendItem("свободно", "seat-free"), legendItem("выбрано", "seat-selected"),
                legendItem("продано", "seat-booked"));
        Label prices = new Label("Ряды 1–2: 90 % цены · последний ряд: 115 % · остальные: 100 %");
        prices.getStyleClass().add("hint");
        VBox hall = new VBox(10, hallCaption, screen, seatGrid, legend, prices);
        hall.setAlignment(Pos.TOP_CENTER);
        hall.getStyleClass().add("panel");
        ScrollPane hallScroll = new ScrollPane(hall);
        hallScroll.setFitToWidth(true);
        VBox center = new VBox(8, Ui.header("Сеансы"), sessionList, Ui.header("Схема зала"), hallScroll);
        VBox.setVgrow(hallScroll, Priority.ALWAYS);
        HBox.setHgrow(center, Priority.ALWAYS);

        // --- правая колонка: покупатель и заказ
        phoneField.setPromptText("+7 999 000-00-01");
        nameField.setPromptText("Фамилия Имя");
        emailField.setPromptText("e-mail (необязательно)");
        Button find = new Button("Найти");
        find.setOnAction(e -> findCustomer());
        phoneField.setOnAction(e -> findCustomer());
        HBox phoneRow = new HBox(6, phoneField, find);
        HBox.setHgrow(phoneField, Priority.ALWAYS);
        customerHint.setWrapText(true);
        customerHint.getStyleClass().add("hint");
        selectedList.setPrefHeight(150);
        totalLabel.getStyleClass().add("total");
        Button book = new Button("Оформить бронирование");
        book.getStyleClass().add("accent");
        book.setMaxWidth(Double.MAX_VALUE);
        book.setOnAction(e -> book());
        Button clear = new Button("Сбросить выбор");
        clear.setMaxWidth(Double.MAX_VALUE);
        clear.setOnAction(e -> { selected.clear(); drawSeats(); });
        resultArea.setEditable(false);
        resultArea.setWrapText(true);
        resultArea.setPrefRowCount(8);
        VBox right = new VBox(8, Ui.header("Покупатель"), new Label("Телефон"), phoneRow, customerHint,
                new Label("Имя"), nameField, emailField, Ui.header("Выбранные места"), selectedList, totalLabel,
                book, clear, resultArea);
        right.setPrefWidth(300);
        VBox.setVgrow(resultArea, Priority.ALWAYS);

        HBox root = new HBox(14, left, center, right);
        root.setPadding(new Insets(12));
        return root;
    }

    private HBox legendItem(String text, String style) {
        Region box = new Region();
        box.setPrefSize(16, 16);
        box.getStyleClass().addAll("legend-box", style);
        HBox h = new HBox(5, box, new Label(text));
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    /** Перечитать фильмы из БД (после изменений администратора). */
    void reload() {
        try {
            Movie current = movieList.getSelectionModel().getSelectedItem();
            List<Movie> movies = catalog.movies();
            movieList.getItems().setAll(movies);
            Movie select = current == null ? null
                    : movies.stream().filter(m -> m.id() == current.id()).findFirst().orElse(null);
            if (select != null) movieList.getSelectionModel().select(select);
            else if (!movies.isEmpty()) movieList.getSelectionModel().selectFirst();
        } catch (BookingException e) {
            Ui.error("Загрузка фильмов", e);
        }
    }

    private void showMovie(Movie m) {
        if (m == null) {
            poster.setImage(null);
            movieInfo.setText("Выберите фильм");
            return;
        }
        poster.setImage(Ui.image(m.posterPath()));
        movieInfo.setText(m.title() + "\n\nЖанр: " + m.genre() + "\nДлительность: " + m.durationMin()
                + " мин.\nВозраст: " + m.ageRating() + "+");
    }

    private void loadSessions() {
        Session current = sessionList.getSelectionModel().getSelectedItem();
        sessionList.getItems().clear();
        Movie m = movieList.getSelectionModel().getSelectedItem();
        if (m == null || dayPicker.getValue() == null) { drawSeats(); return; }
        try {
            List<Session> list = catalog.sessionsForMovie(m.id(), dayPicker.getValue());
            sessionList.getItems().setAll(list);
            if (current != null) list.stream().filter(s -> s.id() == current.id()).findFirst()
                    .ifPresent(s -> sessionList.getSelectionModel().select(s));
            if (list.isEmpty()) sessionList.setPlaceholder(new Label("На эту дату сеансов нет"));
        } catch (BookingException e) {
            Ui.error("Загрузка сеансов", e);
        }
        drawSeats();
    }

    private void drawSeats() {
        seatGrid.getChildren().clear();
        Session s = sessionList.getSelectionModel().getSelectedItem();
        if (s == null) {
            selected.clear();
            hallCaption.setText("Выберите сеанс");
            updateOrder(null);
            return;
        }
        boolean started = s.isStarted(LocalDateTime.now());
        hallCaption.setText(s.hallName() + " · " + s.movieTitle() + " · " + s.startsAt().format(Session.FMT)
                + (started ? " · продажа закрыта" : ""));
        try {
            List<Seat> seats = bookings.seatsForSession(s.id());
            selected.keySet().retainAll(seats.stream().filter(x -> !x.booked()).map(Seat::id).toList());
            for (Seat seat : seats) {
                ToggleButton b = new ToggleButton(String.valueOf(seat.number()));
                b.getStyleClass().add("seat");
                b.setTooltip(new Tooltip(seat + " · " + PriceCalculator.price(s.basePrice(), seat.row(), s.lastRow()) + " ₽"));
                if (seat.booked() || started) {
                    b.setDisable(true);
                    b.getStyleClass().add(seat.booked() ? "seat-booked" : "seat-free");
                } else {
                    b.setSelected(selected.containsKey(seat.id()));
                    b.getStyleClass().add(b.isSelected() ? "seat-selected" : "seat-free");
                    b.setOnAction(e -> {
                        b.getStyleClass().removeAll("seat-free", "seat-selected");
                        if (b.isSelected()) { selected.put(seat.id(), seat); b.getStyleClass().add("seat-selected"); }
                        else { selected.remove(seat.id()); b.getStyleClass().add("seat-free"); }
                        updateOrder(s);
                    });
                }
                seatGrid.add(b, seat.number(), seat.row());
            }
            for (int r = 1; r <= s.lastRow(); r++) {
                Label rowLabel = new Label("Ряд " + r);
                rowLabel.getStyleClass().add("hint");
                seatGrid.add(rowLabel, 0, r);
            }
        } catch (BookingException e) {
            Ui.error("Схема зала", e);
        }
        updateOrder(s);
    }

    private void updateOrder(Session s) {
        selectedList.getItems().clear();
        BigDecimal total = BigDecimal.ZERO;
        if (s != null) {
            for (Seat seat : selected.values()) {
                BigDecimal p = PriceCalculator.price(s.basePrice(), seat.row(), s.lastRow());
                selectedList.getItems().add(seat + " — " + p + " ₽");
                total = total.add(p);
            }
        }
        totalLabel.setText("Итого: " + total + " ₽");
    }

    private void findCustomer() {
        try {
            Optional<Customer> c = bookings.findCustomer(phoneField.getText());
            if (c.isPresent()) {
                nameField.setText(c.get().fullName());
                emailField.setText(c.get().email() == null ? "" : c.get().email());
                customerHint.setText("Постоянный покупатель: " + c.get().phone());
            } else {
                customerHint.setText("Новый покупатель — заполните имя, он будет добавлен при оформлении.");
            }
        } catch (BookingException e) {
            customerHint.setText(e.getMessage());
        }
    }

    private void book() {
        Session s = sessionList.getSelectionModel().getSelectedItem();
        try {
            if (s == null) throw new BookingException("Сначала выберите сеанс.");
            List<Ticket> tickets = bookings.book(s.id(), selected.keySet(), nameField.getText(),
                    phoneField.getText(), emailField.getText());
            BigDecimal total = tickets.stream().map(Ticket::price).reduce(BigDecimal.ZERO, BigDecimal::add);
            StringBuilder sb = new StringBuilder("Бронирование №" + tickets.get(0).bookingId() + " оформлено\n"
                    + "Покупатель: " + tickets.get(0).customerName() + "\n\n");
            tickets.forEach(t -> sb.append(t).append('\n'));
            sb.append("\nИтого: ").append(total).append(" ₽");
            resultArea.setText(sb.toString());
            selected.clear();
            phoneField.clear();
            nameField.clear();
            emailField.clear();
            customerHint.setText("");
        } catch (BookingException e) {
            Ui.error("Бронирование", e);
        }
        loadSessions();   // обновить свободные места и счётчики (в т. ч. после неудачи — место мог купить другой кассир)
    }
}
