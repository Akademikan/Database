package com.example.kinoshka.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Фабрика JDBC-соединений для СУБД, выбранной в настройках. */
public class Database {
    private final AppConfig config;

    public Database(AppConfig config) throws SQLException {
        this.config = config;
        try {
            // JDBC 4 регистрирует драйверы автоматически, но явная загрузка даёт
            // понятное сообщение, если драйвер не попал в classpath
            Class.forName(config.driver());
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC-драйвер " + config.driver() + " не найден в classpath", e);
        }
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(config.url(), config.user(), config.password());
    }

    public Dialect dialect() { return config.dialect(); }

    public AppConfig config() { return config; }

    /** Строка для отображения: СУБД, адрес без параметров и пользователь (без пароля). */
    public String describe() {
        String url = config.url();
        int q = url.indexOf('?');
        return dialect().name() + " · " + (q > 0 ? url.substring(0, q) : url) + " · пользователь " + config.user();
    }
}
