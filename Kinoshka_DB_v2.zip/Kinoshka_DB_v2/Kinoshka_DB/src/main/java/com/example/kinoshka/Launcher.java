package com.example.kinoshka;

import com.example.kinoshka.db.AppConfig;
import com.example.kinoshka.db.Database;
import com.example.kinoshka.db.DbInstaller;
import com.example.kinoshka.ui.MainApp;
import javafx.application.Application;

import java.util.List;

/**
 * Точка входа.
 *
 * Отдельный класс (не наследник Application) нужен, чтобы приложение запускалось
 * обычным {@code java -jar}: иначе JVM требует JavaFX в module-path.
 *
 * Режимы:
 * <pre>
 *   (без параметров)       — графическое приложение
 *   --init-db              — создать таблицы, триггеры и загрузить тестовые данные
 *   --init-db --no-data    — только таблицы и триггеры
 *   --check                — проверить подключение к БД и выйти
 * </pre>
 */
public final class Launcher {
    private Launcher() { }

    public static void main(String[] args) throws Exception {
        List<String> a = List.of(args);
        if (a.contains("--init-db") || a.contains("--check")) {
            AppConfig config = AppConfig.load();
            Database db = new Database(config);
            System.out.println("Настройки: " + config.source());
            System.out.println("Подключение: " + db.describe());
            try (var c = db.getConnection()) {
                var md = c.getMetaData();
                System.out.println("Сервер: " + md.getDatabaseProductName() + " " + md.getDatabaseProductVersion());
                System.out.println("Драйвер: " + md.getDriverName() + " " + md.getDriverVersion());
            }
            if (a.contains("--init-db")) {
                boolean withData = !a.contains("--no-data");
                System.out.println("Создание структуры БД" + (withData ? " и тестовых данных" : "") + "...");
                DbInstaller.install(db, withData);
                System.out.println("Готово.");
            }
            return;
        }
        Application.launch(MainApp.class, args);
    }
}
