package com.example.kinoshka.ui;

import com.example.kinoshka.model.BookingInfo;
import com.example.kinoshka.model.Session;
import com.example.kinoshka.repo.BookingRepository;
import com.example.kinoshka.service.BookingException;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.util.List;
import java.util.function.Function;

/** Вкладка «Бронирования»: поиск бронирований покупателя по телефону и их отмена (возврат). */
class BookingsTab extends Tab {
    private final BookingRepository bookings;
    private final Runnable onChanged;
    private final TextField phoneField = new TextField();
    private final TableView<BookingInfo> table = new TableView<>();
    private final Label summary = new Label();

    BookingsTab(BookingRepository bookings, Runnable onChanged) {
        super("Бронирования");
        this.bookings = bookings;
        this.onChanged = onChanged;
        setClosable(false);

        phoneField.setPromptText("Телефон покупателя, например +79990000001");
        phoneField.setOnAction(e -> search());
        Button find = new Button("Показать");
        find.setOnAction(e -> search());
        Button cancel = new Button("Отменить выбранное бронирование");
        cancel.setOnAction(e -> cancelSelected());
        HBox top = new HBox(8, new Label("Телефон:"), phoneField, find, cancel);
        HBox.setHgrow(phoneField, Priority.ALWAYS);

        table.getColumns().add(column("№", b -> String.valueOf(b.bookingId()), 50));
        table.getColumns().add(column("Оформлено", b -> b.createdAt().format(Session.FMT), 130));
        table.getColumns().add(column("Покупатель", BookingInfo::customerName, 150));
        table.getColumns().add(column("Фильм", BookingInfo::movieTitle, 180));
        table.getColumns().add(column("Сеанс", b -> b.startsAt().format(Session.FMT), 130));
        table.getColumns().add(column("Зал", BookingInfo::hallName, 90));
        table.getColumns().add(column("Места", BookingInfo::seats, 170));
        table.getColumns().add(column("Сумма, ₽", b -> b.total().toPlainString(), 90));
        table.setPlaceholder(new Label("Введите телефон и нажмите «Показать»"));

        VBox root = new VBox(10, Ui.header("Бронирования покупателя"), top, table, summary);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setPadding(new Insets(12));
        setContent(root);
    }

    private static TableColumn<BookingInfo, String> column(String title, Function<BookingInfo, String> getter, double width) {
        TableColumn<BookingInfo, String> c = new TableColumn<>(title);
        c.setCellValueFactory(cd -> new SimpleStringProperty(getter.apply(cd.getValue())));
        c.setPrefWidth(width);
        return c;
    }

    private void search() {
        try {
            List<BookingInfo> list = bookings.bookingsByPhone(phoneField.getText());
            table.getItems().setAll(list);
            int tickets = list.stream().mapToInt(BookingInfo::ticketCount).sum();
            summary.setText(list.isEmpty() ? "Бронирований не найдено."
                    : "Бронирований: " + list.size() + ", билетов: " + tickets);
        } catch (BookingException e) {
            Ui.error("Поиск бронирований", e);
        }
    }

    private void cancelSelected() {
        BookingInfo b = table.getSelectionModel().getSelectedItem();
        if (b == null) { Ui.info("Отмена", "Выберите бронирование в таблице."); return; }
        if (!Ui.confirm("Отмена бронирования", "Отменить бронирование №" + b.bookingId() + " (" + b.movieTitle()
                + ", места: " + b.seats() + ") и вернуть " + b.total() + " ₽?")) return;
        try {
            int freed = bookings.cancelBooking(b.bookingId());
            Ui.info("Отмена бронирования", "Бронирование №" + b.bookingId() + " отменено, освобождено мест: " + freed);
            search();
            onChanged.run();
        } catch (BookingException e) {
            Ui.error("Отмена бронирования", e);
        }
    }
}
