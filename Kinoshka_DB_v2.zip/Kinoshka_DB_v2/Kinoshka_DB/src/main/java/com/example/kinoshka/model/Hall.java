package com.example.kinoshka.model;

/**
 * Кинозал. Количество рядов и мест не хранится в таблице halls —
 * оно вычисляется по таблице seats (rowCount = MAX(row_no), seatCount = COUNT(*)).
 */
public record Hall(int id, String name, int breakMinutes, int rowCount, int seatCount) {
    @Override public String toString() { return name + " (" + seatCount + " мест)"; }
}
