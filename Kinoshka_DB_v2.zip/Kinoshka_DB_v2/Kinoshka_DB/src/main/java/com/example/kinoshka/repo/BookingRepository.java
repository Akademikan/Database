package com.example.kinoshka.repo;

import com.example.kinoshka.db.Database;
import com.example.kinoshka.model.BookingInfo;
import com.example.kinoshka.model.Customer;
import com.example.kinoshka.model.Seat;
import com.example.kinoshka.model.Ticket;
import com.example.kinoshka.service.BookingException;
import com.example.kinoshka.service.PhoneUtil;
import com.example.kinoshka.service.PriceCalculator;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;

/** Продажа и возврат билетов (работа кассира). */
public class BookingRepository {
    private final Database db;

    public BookingRepository(Database db) { this.db = db; }

    /** Схема зала для сеанса: все места зала и отметка, продано ли место. */
    public List<Seat> seatsForSession(int sessionId) throws BookingException {
        String sql = "SELECT st.seat_id, st.row_no, st.seat_no, "
                   + "       CASE WHEN t.ticket_id IS NULL THEN 0 ELSE 1 END AS booked "
                   + "FROM sessions s "
                   + "JOIN seats st ON st.hall_id = s.hall_id "
                   + "LEFT JOIN tickets t ON t.session_id = s.session_id AND t.seat_id = st.seat_id "
                   + "WHERE s.session_id = ? ORDER BY st.row_no, st.seat_no";
        return Jdbc.read(db, c -> {
            List<Seat> list = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, sessionId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) list.add(new Seat(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4) == 1));
                }
            }
            return list;
        });
    }

    public Optional<Customer> findCustomer(String phoneInput) throws BookingException {
        String phone = PhoneUtil.normalize(phoneInput);
        return Jdbc.read(db, c -> findCustomer(c, phone));
    }

    private Optional<Customer> findCustomer(Connection c, String phone) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT customer_id, full_name, phone, email FROM customers WHERE phone = ?")) {
            ps.setString(1, phone);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next()
                        ? Optional.of(new Customer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)))
                        : Optional.empty();
            }
        }
    }

    /**
     * Оформляет бронирование нескольких мест на один сеанс.
     *
     * Всё выполняется в одной транзакции: покупатель (если новый) → бронирование →
     * билеты. Если хотя бы одно место уже продано (UNIQUE uq_tickets_sold) или
     * не принадлежит залу (триггер KN001), откатывается всё — частичной продажи не бывает.
     *
     * Цена и данные сеанса читаются из БД внутри транзакции, а не берутся из
     * интерфейса: за время, пока кассир выбирал места, цену могли изменить.
     */
    public List<Ticket> book(int sessionId, Collection<Integer> seatIds, String fullName, String phoneInput,
                             String email) throws BookingException {
        String name = fullName == null ? "" : fullName.trim();
        String phone = PhoneUtil.normalize(phoneInput);
        String mail = (email == null || email.isBlank()) ? null : email.trim();
        if (seatIds == null || seatIds.isEmpty()) throw new BookingException("Выберите хотя бы одно место.");
        // упорядочиваем места: параллельные транзакции блокируют строки в одном порядке → нет взаимных блокировок
        TreeSet<Integer> ordered = new TreeSet<>(seatIds);

        return Jdbc.inTransaction(db, c -> {
            SessionData s = loadSession(c, sessionId);
            if (!s.startsAt.isAfter(LocalDateTime.now()))
                throw new BookingException("Сеанс уже начался — продажа закрыта.");

            Customer customer = findCustomer(c, phone).orElse(null);
            int customerId;
            String customerName;
            if (customer == null) {
                if (name.isEmpty()) throw new BookingException("Новый покупатель: укажите имя.");
                customerId = Jdbc.insertReturningId(c,
                        "INSERT INTO customers (full_name, phone, email) VALUES (?, ?, ?)", "customer_id", name, phone, mail);
                customerName = name;
            } else {
                customerId = customer.id();
                customerName = customer.fullName();
            }

            int bookingId = Jdbc.insertReturningId(c, "INSERT INTO bookings (customer_id, created_at) VALUES (?, ?)",
                    "booking_id", customerId, LocalDateTime.now().withNano(0));

            List<Ticket> tickets = new ArrayList<>();
            for (int seatId : ordered) {
                int[] place = seatPlace(c, seatId);
                BigDecimal price = PriceCalculator.price(s.basePrice, place[0], s.lastRow);
                int ticketId = Jdbc.insertReturningId(c,
                        "INSERT INTO tickets (booking_id, session_id, seat_id, price) VALUES (?, ?, ?, ?)",
                        "ticket_id", bookingId, sessionId, seatId, price);
                tickets.add(new Ticket(ticketId, bookingId, customerName, s.title, s.hallName, s.startsAt,
                        place[0], place[1], price));
            }
            return tickets;
        });
    }

    /** Бронирования покупателя (по телефону), новые сверху. */
    public List<BookingInfo> bookingsByPhone(String phoneInput) throws BookingException {
        String phone = PhoneUtil.normalize(phoneInput);
        String seats = db.dialect().stringAgg(
                "CONCAT('р', st.row_no, 'м', st.seat_no)",
                "st.row_no, st.seat_no", ", ");
        String sql = "SELECT b.booking_id, b.created_at, c.full_name, m.title, h.name, s.starts_at, "
                   + seats + " AS seats, COUNT(*) AS cnt, SUM(t.price) AS total "
                   + "FROM bookings b "
                   + "JOIN customers c ON c.customer_id = b.customer_id "
                   + "JOIN tickets t ON t.booking_id = b.booking_id "
                   + "JOIN sessions s ON s.session_id = t.session_id "
                   + "JOIN movies m ON m.movie_id = s.movie_id "
                   + "JOIN halls h ON h.hall_id = s.hall_id "
                   + "JOIN seats st ON st.seat_id = t.seat_id "
                   + "WHERE c.phone = ? "
                   + "GROUP BY b.booking_id, b.created_at, c.full_name, m.title, h.name, s.starts_at "
                   + "ORDER BY b.created_at DESC, b.booking_id DESC";
        return Jdbc.read(db, c -> {
            List<BookingInfo> list = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, phone);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) list.add(new BookingInfo(rs.getInt(1), Jdbc.dateTime(rs, "created_at"),
                            rs.getString(3), rs.getString(4), rs.getString(5), Jdbc.dateTime(rs, "starts_at"),
                            rs.getString(7), rs.getInt(8), rs.getBigDecimal(9)));
                }
            }
            return list;
        });
    }

    /**
     * Отмена бронирования: удаляется строка bookings, билеты удаляются
     * каскадно (fk_tickets_booking ON DELETE CASCADE), места освобождаются.
     * Отменить можно только до начала сеанса.
     * @return число освобождённых мест
     */
    public int cancelBooking(int bookingId) throws BookingException {
        return Jdbc.inTransaction(db, c -> {
            int tickets;
            LocalDateTime firstStart;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT COUNT(*), MIN(s.starts_at) AS first_start FROM tickets t "
                  + "JOIN sessions s ON s.session_id = t.session_id WHERE t.booking_id = ?")) {
                ps.setInt(1, bookingId);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    tickets = rs.getInt(1);
                    firstStart = Jdbc.dateTime(rs, "first_start");
                }
            }
            if (firstStart != null && !firstStart.isAfter(LocalDateTime.now()))
                throw new BookingException("Сеанс уже начался — бронирование отменить нельзя.");
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM bookings WHERE booking_id = ?")) {
                ps.setInt(1, bookingId);
                if (ps.executeUpdate() == 0) throw new BookingException("Бронирование №" + bookingId + " не найдено.");
            }
            return tickets;
        });
    }

    // ------------------------------------------------------------------ служебное

    private record SessionData(String title, String hallName, LocalDateTime startsAt, BigDecimal basePrice, int lastRow) { }

    private SessionData loadSession(Connection c, int sessionId) throws SQLException, BookingException {
        String sql = "SELECT m.title, h.name, s.starts_at, s.base_price, "
                   + "(SELECT MAX(x.row_no) FROM seats x WHERE x.hall_id = s.hall_id) "
                   + "FROM sessions s JOIN movies m ON m.movie_id = s.movie_id JOIN halls h ON h.hall_id = s.hall_id "
                   + "WHERE s.session_id = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, sessionId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new BookingException("Сеанс не найден — возможно, его удалили.");
                return new SessionData(rs.getString(1), rs.getString(2), Jdbc.dateTime(rs, "starts_at"),
                        rs.getBigDecimal(4), rs.getInt(5));
            }
        }
    }

    /** Ряд и номер места; если места нет — понятная ошибка. */
    private int[] seatPlace(Connection c, int seatId) throws SQLException, BookingException {
        try (PreparedStatement ps = c.prepareStatement("SELECT row_no, seat_no FROM seats WHERE seat_id = ?")) {
            ps.setInt(1, seatId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new BookingException("Место №" + seatId + " не найдено.");
                return new int[]{rs.getInt(1), rs.getInt(2)};
            }
        }
    }
}
