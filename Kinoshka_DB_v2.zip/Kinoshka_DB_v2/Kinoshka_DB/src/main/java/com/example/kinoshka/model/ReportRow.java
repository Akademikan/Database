package com.example.kinoshka.model;

import java.util.List;

/** Строка отчёта: значения столбцов в виде текста (отчёты только отображаются). */
public record ReportRow(List<String> cells) { }
