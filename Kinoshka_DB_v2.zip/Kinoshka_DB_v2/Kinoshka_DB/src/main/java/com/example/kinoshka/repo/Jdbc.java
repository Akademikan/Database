package com.example.kinoshka.repo;

import com.example.kinoshka.db.Database;
import com.example.kinoshka.service.BookingException;
import com.example.kinoshka.service.ErrorTranslator;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

/** Вспомогательные методы JDBC: транзакции, чтение дат, получение сгенерированных ключей. */
final class Jdbc {

    @FunctionalInterface
    interface Work<T> {
        T run(Connection c) throws SQLException, BookingException;
    }

    private Jdbc() { }

    /**
     * Выполняет работу в одной транзакции: при любой ошибке — ROLLBACK,
     * иначе COMMIT. Ошибки СУБД переводятся в понятные пользователю сообщения.
     */
    static <T> T inTransaction(Database db, Work<T> work) throws BookingException {
        try (Connection c = db.getConnection()) {
            c.setAutoCommit(false);
            try {
                T result = work.run(c);
                c.commit();
                return result;
            } catch (SQLException | BookingException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw ErrorTranslator.translate(e);
        }
    }

    /** Выполняет только чтение (autocommit), с переводом ошибок. */
    static <T> T read(Database db, Work<T> work) throws BookingException {
        try (Connection c = db.getConnection()) {
            return work.run(c);
        } catch (SQLException e) {
            throw ErrorTranslator.translate(e);
        }
    }

    /** INSERT с возвратом сгенерированного первичного ключа. */
    static int insertReturningId(Connection c, String sql, String idColumn, Object... params) throws SQLException {
        // Имя столбца нужно PostgreSQL (иначе он вернёт всю строку), MySQL его игнорирует
        try (PreparedStatement ps = c.prepareStatement(sql, new String[]{idColumn})) {
            bind(ps, params);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (!rs.next()) throw new SQLException("СУБД не вернула сгенерированный ключ " + idColumn);
                return rs.getInt(1);
            }
        }
    }

    static void bind(PreparedStatement ps, Object... params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            Object p = params[i];
            if (p == null) ps.setNull(i + 1, java.sql.Types.VARCHAR);   // в проекте NULL передаются только в строковые столбцы
            else ps.setObject(i + 1, p);   // LocalDateTime, BigDecimal, Integer, String — стандарт JDBC 4.2
        }
    }

    /** Чтение TIMESTAMP/DATETIME без пересчёта часовых поясов. */
    static LocalDateTime dateTime(ResultSet rs, String column) throws SQLException {
        return rs.getObject(column, LocalDateTime.class);
    }
}
