package com.example.kinoshka.ui;

import com.example.kinoshka.db.AppConfig;
import com.example.kinoshka.db.Database;
import com.example.kinoshka.repo.BookingRepository;
import com.example.kinoshka.repo.CatalogRepository;
import com.example.kinoshka.repo.ReportRepository;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.sql.Connection;

/** Главное окно: вкладки «Касса», «Бронирования», «Администратор», «Отчёты». */
public class MainApp extends Application {

    @Override
    public void start(Stage stage) {
        Database db;
        try {
            AppConfig config = AppConfig.load();
            db = new Database(config);
            try (Connection ignored = db.getConnection()) {
                // проверка соединения до показа окна
            }
        } catch (Exception e) {
            Ui.error("Нет подключения к базе данных", new Exception(e.getMessage()
                    + "\n\nПроверьте файл config/db.properties (образец — config/db.properties.example), "
                    + "что сервер СУБД запущен и база создана (см. README, раздел «Развёртывание»)."));
            Platform.exit();
            return;
        }

        CatalogRepository catalog = new CatalogRepository(db);
        BookingRepository bookings = new BookingRepository(db);
        ReportRepository reports = new ReportRepository(db);

        CashierTab cashier = new CashierTab(catalog, bookings);
        ReportsTab reportsTab = new ReportsTab(reports);
        // Администратор и возврат билетов сообщают об изменениях, чтобы касса показала актуальные данные
        AdminTab[] adminRef = new AdminTab[1];
        Runnable refreshAll = () -> { cashier.reload(); if (adminRef[0] != null) adminRef[0].reload(); };
        AdminTab adminTab = new AdminTab(catalog, refreshAll);
        adminRef[0] = adminTab;
        BookingsTab bookingsTab = new BookingsTab(bookings, refreshAll);

        TabPane tabs = new TabPane(cashier, bookingsTab, adminTab, reportsTab);
        tabs.getSelectionModel().selectedItemProperty().addListener((o, a, t) -> {
            if (t == adminTab) adminTab.reload();
            if (t == reportsTab) reportsTab.run();
            if (t == cashier) cashier.reload();
        });

        Label status = new Label("Подключено: " + db.describe() + " · настройки: " + db.config().source());
        status.getStyleClass().add("status");
        status.setMaxWidth(Double.MAX_VALUE);
        BorderPane root = new BorderPane(tabs);
        root.setBottom(status);

        Scene scene = new Scene(root, 1280, 820);
        scene.getStylesheets().add(MainApp.class.getResource("/com/example/kinoshka/app.css").toExternalForm());
        stage.setTitle("Kinoshka — кинотеатр (" + db.dialect().name() + ")");
        Image icon = Ui.image("/com/example/kinoshka/icons/cinema_icon.png");
        if (icon != null) stage.getIcons().add(icon);
        stage.setScene(scene);
        stage.show();
        cashier.reload();
    }
}
