package com.example.kinoshka.ui;

import com.example.kinoshka.service.BookingException;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Optional;

/** Общие элементы интерфейса: диалоги, разбор чисел, загрузка картинок. */
final class Ui {
    private Ui() { }

    static void error(String title, Throwable e) {
        String msg = e instanceof NumberFormatException
                ? "Проверьте числовые поля: " + e.getMessage()
                : (e.getMessage() == null ? e.toString() : e.getMessage());
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setTitle(title);
        a.setHeaderText(title);
        a.showAndWait();
    }

    static void info(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        a.setTitle(title);
        a.setHeaderText(title);
        a.showAndWait();
    }

    static boolean confirm(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, msg, ButtonType.YES, ButtonType.NO);
        a.setTitle(title);
        a.setHeaderText(title);
        Optional<ButtonType> r = a.showAndWait();
        return r.isPresent() && r.get() == ButtonType.YES;
    }

    static int parseInt(String text, String field) throws BookingException {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            throw new BookingException("Поле «" + field + "»: нужно целое число.");
        }
    }

    static BigDecimal parseMoney(String text, String field) throws BookingException {
        try {
            return new BigDecimal(text.trim().replace(',', '.'));
        } catch (NumberFormatException e) {
            throw new BookingException("Поле «" + field + "»: нужна сумма, например 350 или 350.50.");
        }
    }

    /** DatePicker с форматом дд.мм.гггг независимо от языка ОС (в англоязычной системе иначе будет M/d/yyyy). */
    static javafx.scene.control.DatePicker datePicker(java.time.LocalDate value) {
        javafx.scene.control.DatePicker p = new javafx.scene.control.DatePicker(value);
        java.time.format.DateTimeFormatter f = java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy");
        p.setConverter(new javafx.util.StringConverter<>() {
            @Override public String toString(java.time.LocalDate d) { return d == null ? "" : f.format(d); }
            @Override public java.time.LocalDate fromString(String s) {
                return s == null || s.isBlank() ? null : java.time.LocalDate.parse(s.trim(), f);
            }
        });
        p.setPromptText("дд.мм.гггг");
        return p;
    }

    static Label header(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("section-header");
        return l;
    }

    static Image image(String resourcePath) {
        if (resourcePath == null) return null;
        try (InputStream in = Ui.class.getResourceAsStream(resourcePath)) {
            return in == null ? null : new Image(in);
        } catch (Exception e) {
            return null;
        }
    }
}
