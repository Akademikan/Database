package com.example.kinoshka.model;

/** Фильм (таблица movies + название жанра). */
public record Movie(int id, String title, int genreId, String genre, int durationMin, int ageRating, String posterPath) {
    @Override public String toString() { return title + " (" + ageRating + "+)"; }
}
