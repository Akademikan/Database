package com.example.kinoshka.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Правило ценообразования: ряды 1–2 — 90 % базовой цены (близко к экрану),
 * последний ряд зала — 115 % (лучший обзор), остальные — 100 %.
 * Деньги считаются в BigDecimal: double даёт ошибки округления (0.1 + 0.2 ≠ 0.3).
 */
public final class PriceCalculator {
    public static final BigDecimal FRONT_COEF = new BigDecimal("0.90");
    public static final BigDecimal LAST_COEF  = new BigDecimal("1.15");
    public static final int FRONT_ROWS = 2;

    private PriceCalculator() { }

    /**
     * @param basePrice базовая цена сеанса
     * @param row       номер ряда (с 1)
     * @param lastRow   номер последнего ряда в зале
     */
    public static BigDecimal price(BigDecimal basePrice, int row, int lastRow) {
        if (basePrice == null || basePrice.signum() <= 0)
            throw new IllegalArgumentException("Базовая цена должна быть положительной");
        if (row < 1 || row > lastRow)
            throw new IllegalArgumentException("Ряд " + row + " вне диапазона 1.." + lastRow);
        BigDecimal coef;
        if (row <= FRONT_ROWS) coef = FRONT_COEF;      // приоритет у «передних» рядов, если зал маленький
        else if (row == lastRow) coef = LAST_COEF;
        else coef = BigDecimal.ONE;
        return basePrice.multiply(coef).setScale(2, RoundingMode.HALF_UP);
    }
}
