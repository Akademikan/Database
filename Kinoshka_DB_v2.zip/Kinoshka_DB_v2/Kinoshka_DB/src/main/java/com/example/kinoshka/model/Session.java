package com.example.kinoshka.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Сеанс вместе с данными фильма и зала, нужными интерфейсу. */
public record Session(int id, int movieId, String movieTitle, int durationMin,
                      int hallId, String hallName, LocalDateTime startsAt,
                      BigDecimal basePrice, int lastRow, int soldCount, int seatCount) {

    public static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

    public LocalDateTime endsAt() { return startsAt.plusMinutes(durationMin); }

    public boolean isStarted(LocalDateTime now) { return !startsAt.isAfter(now); }

    @Override public String toString() {
        return startsAt.format(FMT) + "–" + endsAt().toLocalTime() + " | " + hallName
                + " | от " + basePrice + " ₽ | свободно " + (seatCount - soldCount) + " из " + seatCount;
    }
}
