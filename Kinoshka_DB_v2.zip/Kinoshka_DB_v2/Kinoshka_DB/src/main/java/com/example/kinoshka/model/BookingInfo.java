package com.example.kinoshka.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Бронирование для списка «Мои бронирования»: одна строка на бронирование. */
public record BookingInfo(int bookingId, LocalDateTime createdAt, String customerName, String movieTitle,
                          String hallName, LocalDateTime startsAt, String seats, int ticketCount, BigDecimal total) { }
