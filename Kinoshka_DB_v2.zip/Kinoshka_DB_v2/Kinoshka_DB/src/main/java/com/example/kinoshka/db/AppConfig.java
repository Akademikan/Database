package com.example.kinoshka.db;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;

/**
 * Настройки подключения к БД.
 *
 * Порядок поиска файла (используется первый найденный):
 * <ol>
 *   <li>путь из системного свойства {@code -Dkinoshka.config=...};</li>
 *   <li>путь из переменной окружения {@code KINOSHKA_CONFIG};</li>
 *   <li>{@code config/db.properties} в текущем каталоге;</li>
 *   <li>{@code db.properties} внутри приложения (значения по умолчанию).</li>
 * </ol>
 * Пароль можно не хранить в файле, а задать переменной окружения
 * {@code KINOSHKA_DB_PASSWORD}: она имеет приоритет над файлом.
 * Файл читается в UTF-8, поэтому одинаково работает в Windows и Linux.
 */
public final class AppConfig {
    public static final String SYSTEM_PROPERTY = "kinoshka.config";
    public static final String ENV_CONFIG = "KINOSHKA_CONFIG";
    public static final String ENV_PASSWORD = "KINOSHKA_DB_PASSWORD";
    public static final Path DEFAULT_FILE = Path.of("config", "db.properties");

    private final Properties props;
    private final String source;
    private final Map<String, String> env;

    private AppConfig(Properties props, String source, Map<String, String> env) {
        this.props = props;
        this.source = source;
        this.env = env;
    }

    /** Загружает настройки по правилам, описанным в комментарии к классу. */
    public static AppConfig load() throws IOException {
        return load(System.getenv(), Path.of("").toAbsolutePath());
    }

    /** Вариант для тестов: окружение и рабочий каталог передаются явно. */
    static AppConfig load(Map<String, String> env, Path workDir) throws IOException {
        String sys = System.getProperty(SYSTEM_PROPERTY);
        if (sys != null && !sys.isBlank()) return fromFile(Path.of(sys), env);
        String envPath = env.get(ENV_CONFIG);
        if (envPath != null && !envPath.isBlank()) return fromFile(Path.of(envPath), env);
        Path local = workDir.resolve(DEFAULT_FILE);
        if (Files.isRegularFile(local)) return fromFile(local, env);
        try (InputStream in = AppConfig.class.getResourceAsStream("/db.properties")) {
            if (in == null) throw new IOException("Не найден файл настроек: ни " + local
                    + ", ни db.properties внутри приложения");
            Properties p = new Properties();
            p.load(new InputStreamReader(in, StandardCharsets.UTF_8));
            return new AppConfig(p, "встроенный db.properties", env);
        }
    }

    public static AppConfig fromFile(Path file) throws IOException {
        return fromFile(file, System.getenv());
    }

    private static AppConfig fromFile(Path file, Map<String, String> env) throws IOException {
        if (!Files.isRegularFile(file))
            throw new IOException("Файл настроек не найден: " + file.toAbsolutePath());
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            p.load(r);
        }
        return new AppConfig(p, file.toAbsolutePath().toString(), env);
    }

    public static AppConfig fromProperties(Properties p, String source) {
        return new AppConfig(p, source, Map.of());
    }

    public Dialect dialect() {
        return Dialect.fromKey(props.getProperty("db.type", "postgresql"));
    }

    public String url()  { return required(prefix() + "url"); }
    public String user() { return required(prefix() + "user"); }

    public String password() {
        String fromEnv = env.get(ENV_PASSWORD);
        if (fromEnv != null) return fromEnv;
        return props.getProperty(prefix() + "password", "");
    }

    /** Класс JDBC-драйвера; можно переопределить ключом {@code <тип>.driver}. */
    public String driver() {
        return props.getProperty(prefix() + "driver", dialect().defaultDriver()).trim();
    }

    /** Откуда загружены настройки (показывается в строке состояния). */
    public String source() { return source; }

    private String prefix() { return dialect().key() + "."; }

    private String required(String key) {
        String v = props.getProperty(key);
        if (v == null || v.isBlank())
            throw new IllegalStateException("В настройках (" + source + ") не задан параметр " + key);
        return v.trim();
    }
}
