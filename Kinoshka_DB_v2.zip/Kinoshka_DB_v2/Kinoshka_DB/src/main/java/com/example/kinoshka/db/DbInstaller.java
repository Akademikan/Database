package com.example.kinoshka.db;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * Создание структуры БД и загрузка тестовых данных из скриптов каталога database/.
 * Запускается из приложения: {@code --init-db} (схема + триггеры + данные)
 * или {@code --init-db --no-data} (только схема и триггеры).
 *
 * База данных и пользователь должны уже существовать (скрипт 00_create_db_user.sql
 * выполняет администратор СУБД).
 */
public final class DbInstaller {
    public static final List<String> SCHEMA_SCRIPTS = List.of("01_schema.sql", "02_triggers.sql");
    public static final String DATA_SCRIPT = "03_data.sql";

    private DbInstaller() { }

    public static void install(Database db, boolean withData) throws SQLException, IOException {
        try (Connection c = db.getConnection()) {
            for (String name : SCHEMA_SCRIPTS) runOne(c, db.dialect(), name);
            if (withData) runOne(c, db.dialect(), DATA_SCRIPT);
        }
    }

    private static void runOne(Connection c, Dialect dialect, String name) throws SQLException, IOException {
        String script = readScript(dialect, name);
        int count = ScriptRunner.run(c, script, dialect);
        System.out.println("  " + dialect.key() + "/" + name + ": выполнено команд — " + count);
    }

    /**
     * Скрипт ищется сначала в каталоге database/ рядом с программой
     * (можно править без пересборки), затем внутри приложения (/db/...).
     */
    static String readScript(Dialect dialect, String name) throws IOException {
        Path local = Path.of("database", dialect.key(), name);
        if (Files.isRegularFile(local)) return Files.readString(local, StandardCharsets.UTF_8);
        String resource = "/db/" + dialect.key() + "/" + name;
        try (InputStream in = DbInstaller.class.getResourceAsStream(resource)) {
            if (in == null) throw new IOException("Скрипт не найден: " + local.toAbsolutePath() + " и " + resource);
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
