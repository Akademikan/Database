package com.example.kinoshka.db;

/**
 * Поддерживаемые СУБД и различия в SQL между ними.
 * Всё, что зависит от конкретной СУБД, собрано здесь; репозитории пишут
 * переносимый SQL и обращаются к диалекту только в этих местах.
 */
public enum Dialect {
    POSTGRESQL("postgresql", "org.postgresql.Driver"),
    MYSQL("mysql", "com.mysql.cj.jdbc.Driver");

    private final String key;
    private final String defaultDriver;

    Dialect(String key, String defaultDriver) {
        this.key = key;
        this.defaultDriver = defaultDriver;
    }

    /** Ключ в файле настроек и имя каталога со скриптами: postgresql / mysql. */
    public String key() { return key; }

    public String defaultDriver() { return defaultDriver; }

    public static Dialect fromKey(String value) {
        if (value != null) {
            for (Dialect d : values()) {
                if (d.key.equalsIgnoreCase(value.trim())) return d;
            }
        }
        throw new IllegalArgumentException("Неподдерживаемая СУБД в db.type: '" + value
                + "'. Допустимо: postgresql, mysql");
    }

    /**
     * Агрегатная конкатенация строк: STRING_AGG в PostgreSQL, GROUP_CONCAT в MySQL.
     * @param expr      строковое выражение
     * @param orderBy   порядок внутри группы
     * @param separator разделитель
     */
    public String stringAgg(String expr, String orderBy, String separator) {
        return switch (this) {
            case POSTGRESQL -> "STRING_AGG(" + expr + ", '" + separator + "' ORDER BY " + orderBy + ")";
            case MYSQL -> "GROUP_CONCAT(" + expr + " ORDER BY " + orderBy + " SEPARATOR '" + separator + "')";
        };
    }
}
