package com.example.kinoshka.repo;

import com.example.kinoshka.db.Database;
import com.example.kinoshka.model.ReportRow;
import com.example.kinoshka.service.BookingException;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Отчёты для администратора: агрегирующие запросы с GROUP BY и внешними соединениями. */
public class ReportRepository {

    /** Результат отчёта: заголовки столбцов и строки. */
    public record Report(String title, List<String> headers, List<ReportRow> rows) { }

    private final Database db;

    public ReportRepository(Database db) { this.db = db; }

    /** Выручка по фильмам (LEFT JOIN: фильмы без продаж тоже попадают в отчёт с нулями). */
    public Report revenueByMovie() throws BookingException {
        String sql = "SELECT m.title AS \"Фильм\", g.name AS \"Жанр\", "
                   + "COUNT(DISTINCT s.session_id) AS \"Сеансов\", COUNT(t.ticket_id) AS \"Билетов\", "
                   + "COALESCE(SUM(t.price), 0) AS \"Выручка, ₽\" "
                   + "FROM movies m JOIN genres g ON g.genre_id = m.genre_id "
                   + "LEFT JOIN sessions s ON s.movie_id = m.movie_id "
                   + "LEFT JOIN tickets t ON t.session_id = s.session_id "
                   + "GROUP BY m.movie_id, m.title, g.name "
                   + "ORDER BY 5 DESC, m.title";
        return query("Выручка по фильмам", sql);
    }

    /** Заполняемость сеансов выбранного дня. */
    public Report occupancy(LocalDate day) throws BookingException {
        String sql = "SELECT s.starts_at AS \"Начало\", h.name AS \"Зал\", m.title AS \"Фильм\", "
                   + "(SELECT COUNT(*) FROM tickets t WHERE t.session_id = s.session_id) AS \"Продано\", "
                   + "(SELECT COUNT(*) FROM seats x WHERE x.hall_id = s.hall_id) AS \"Мест\", "
                   + "ROUND(100.0 * (SELECT COUNT(*) FROM tickets t WHERE t.session_id = s.session_id) "
                   + "      / NULLIF((SELECT COUNT(*) FROM seats x WHERE x.hall_id = s.hall_id), 0), 1) AS \"Заполнено, %\" "
                   + "FROM sessions s JOIN halls h ON h.hall_id = s.hall_id JOIN movies m ON m.movie_id = s.movie_id "
                   + "WHERE s.starts_at >= ? AND s.starts_at < ? "
                   + "ORDER BY s.starts_at, h.name";
        return query("Заполняемость сеансов " + day, sql, day.atStartOfDay(), day.plusDays(1).atStartOfDay());
    }

    /** Покупатели: число бронирований, билетов и сумма покупок (HAVING отсеивает тех, у кого покупок нет). */
    public Report customers() throws BookingException {
        String sql = "SELECT c.full_name AS \"Покупатель\", c.phone AS \"Телефон\", "
                   + "COUNT(DISTINCT b.booking_id) AS \"Бронирований\", COUNT(t.ticket_id) AS \"Билетов\", "
                   + "SUM(t.price) AS \"Сумма, ₽\" "
                   + "FROM customers c JOIN bookings b ON b.customer_id = c.customer_id "
                   + "JOIN tickets t ON t.booking_id = b.booking_id "
                   + "GROUP BY c.customer_id, c.full_name, c.phone "
                   + "HAVING COUNT(t.ticket_id) > 0 "
                   + "ORDER BY 5 DESC";
        return query("Покупатели", sql);
    }

    /** Все проданные билеты (соединение 7 таблиц). */
    public Report tickets() throws BookingException {
        String sql = "SELECT t.ticket_id AS \"№\", c.full_name AS \"Покупатель\", c.phone AS \"Телефон\", m.title AS \"Фильм\", "
                   + "s.starts_at AS \"Сеанс\", h.name AS \"Зал\", st.row_no AS \"Ряд\", st.seat_no AS \"Место\", "
                   + "t.price AS \"Цена, ₽\" "
                   + "FROM tickets t "
                   + "JOIN bookings b ON b.booking_id = t.booking_id "
                   + "JOIN customers c ON c.customer_id = b.customer_id "
                   + "JOIN sessions s ON s.session_id = t.session_id "
                   + "JOIN movies m ON m.movie_id = s.movie_id "
                   + "JOIN halls h ON h.hall_id = s.hall_id "
                   + "JOIN seats st ON st.seat_id = t.seat_id "
                   + "ORDER BY s.starts_at, h.name, st.row_no, st.seat_no";
        return query("Проданные билеты", sql);
    }

    /** Итоги: число билетов и выручка (для проверки отчётов в тестах). */
    public BigDecimal totalRevenue() throws BookingException {
        return Jdbc.read(db, c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT COALESCE(SUM(price), 0) FROM tickets");
                 ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getBigDecimal(1);
            }
        });
    }

    private Report query(String title, String sql, Object... params) throws BookingException {
        return Jdbc.read(db, c -> {
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                Jdbc.bind(ps, params);
                try (ResultSet rs = ps.executeQuery()) {
                    ResultSetMetaData md = rs.getMetaData();
                    List<String> headers = new ArrayList<>();
                    for (int i = 1; i <= md.getColumnCount(); i++) headers.add(md.getColumnLabel(i));
                    List<ReportRow> rows = new ArrayList<>();
                    while (rs.next()) {
                        List<String> cells = new ArrayList<>();
                        for (int i = 1; i <= md.getColumnCount(); i++) cells.add(format(rs.getObject(i)));
                        rows.add(new ReportRow(cells));
                    }
                    return new Report(title, headers, rows);
                }
            }
        });
    }

    private static String format(Object v) {
        if (v == null) return "";
        if (v instanceof java.sql.Timestamp ts) v = ts.toLocalDateTime();
        if (v instanceof LocalDateTime dt) return dt.format(com.example.kinoshka.model.Session.FMT);
        if (v instanceof BigDecimal bd) return bd.stripTrailingZeros().scale() <= 0
                ? bd.setScale(0, java.math.RoundingMode.UNNECESSARY).toPlainString() : bd.toPlainString();
        return v.toString();
    }
}
