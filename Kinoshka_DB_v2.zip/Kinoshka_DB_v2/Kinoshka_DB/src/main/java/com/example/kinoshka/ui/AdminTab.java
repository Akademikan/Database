package com.example.kinoshka.ui;

import com.example.kinoshka.model.Genre;
import com.example.kinoshka.model.Hall;
import com.example.kinoshka.model.Movie;
import com.example.kinoshka.model.Session;
import com.example.kinoshka.repo.CatalogRepository;
import com.example.kinoshka.service.BookingException;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Вкладка «Администратор»: фильмы, сеансы, залы. */
class AdminTab extends Tab {
    /** Постеры, встроенные в приложение: подпись → путь к ресурсу. */
    private static final Map<String, String> POSTERS = new LinkedHashMap<>();
    static {
        String base = "/com/example/kinoshka/posters/";
        POSTERS.put("Стандартный постер", base + "default.png");
        POSTERS.put("Интерстеллар", base + "interstellar.png");
        POSTERS.put("Начало", base + "inception.png");
        POSTERS.put("Кунг-фу Панда", base + "kungfu_panda.png");
        POSTERS.put("Наследник", base + "heir.png");
        POSTERS.put("Новая тёща", base + "new_mother_in_law.png");
        POSTERS.put("К себе нежно", base + "be_gentle_to_yourself.png");
        POSTERS.put("Горничная", base + "maid.png");
        POSTERS.put("Два, три, призрак, приди!", base + "two_three_ghost_come.png");
    }

    private final CatalogRepository catalog;
    private final Runnable onChanged;

    // фильм
    private final TextField titleField = new TextField();
    private final ComboBox<String> genreBox = new ComboBox<>();
    private final TextField durationField = new TextField();
    private final ChoiceBox<Integer> ageBox = new ChoiceBox<>();
    private final ChoiceBox<String> posterBox = new ChoiceBox<>();
    // сеансы
    private final ComboBox<Movie> movieBox = new ComboBox<>();
    private final ComboBox<Hall> hallBox = new ComboBox<>();
    private final DatePicker firstDay = Ui.datePicker(LocalDate.now().plusDays(1));
    private final TextField timeField = new TextField("19:00");
    private final TextField daysField = new TextField("1");
    private final TextField priceField = new TextField("350");
    private final DatePicker viewDay = Ui.datePicker(LocalDate.now());
    private final ListView<Session> daySessions = new ListView<>();
    // зал
    private final TextField hallName = new TextField();
    private final TextField hallRows = new TextField("5");
    private final TextField hallPerRow = new TextField("8");
    private final TextField hallBreak = new TextField("15");

    AdminTab(CatalogRepository catalog, Runnable onChanged) {
        super("Администратор");
        this.catalog = catalog;
        this.onChanged = onChanged;
        setClosable(false);

        VBox root = new VBox(14, movieSection(), sessionSection(), hallSection());
        root.setPadding(new Insets(12));
        ScrollPane scroll = new ScrollPane(root);
        scroll.setFitToWidth(true);
        setContent(scroll);
    }

    private VBox movieSection() {
        titleField.setPromptText("Название");
        genreBox.setEditable(true);
        genreBox.setPromptText("Жанр (можно ввести новый)");
        durationField.setPromptText("минут");
        ageBox.getItems().addAll(0, 6, 12, 16, 18);
        ageBox.setValue(12);
        posterBox.getItems().addAll(POSTERS.keySet());
        posterBox.setValue("Стандартный постер");
        Button add = new Button("Добавить фильм");
        add.setOnAction(e -> addMovie());
        GridPane g = grid();
        g.addRow(0, new Label("Название"), titleField, new Label("Жанр"), genreBox);
        g.addRow(1, new Label("Длительность, мин"), durationField, new Label("Возраст"), ageBox);
        g.addRow(2, new Label("Постер"), posterBox, new Label(""), add);
        return section("Новый фильм", g, new Label("Если жанра нет в справочнике, он будет создан в той же транзакции."));
    }

    private VBox sessionSection() {
        movieBox.setPrefWidth(260);
        hallBox.setPrefWidth(200);
        Button add = new Button("Добавить сеансы");
        add.setOnAction(e -> addSessions());
        GridPane g = grid();
        g.addRow(0, new Label("Фильм"), movieBox, new Label("Зал"), hallBox);
        g.addRow(1, new Label("Первый день"), firstDay, new Label("Время (ЧЧ:ММ)"), timeField);
        g.addRow(2, new Label("Дней подряд"), daysField, new Label("Базовая цена, ₽"), priceField);
        g.add(add, 3, 3);

        viewDay.setOnAction(e -> loadDay());
        Button delete = new Button("Удалить выбранный сеанс");
        delete.setOnAction(e -> deleteSession());
        daySessions.setPrefHeight(220);
        daySessions.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Session s, boolean empty) {
                super.updateItem(s, empty);
                setText(empty || s == null ? null : s.hallName() + " | " + s.startsAt().toLocalTime() + "–"
                        + s.endsAt().toLocalTime() + " | " + s.movieTitle() + " | продано " + s.soldCount());
            }
        });
        HBox dayRow = new HBox(8, new Label("Расписание на"), viewDay, delete);
        return section("Сеансы", g,
                new Label("Сеансы на несколько дней добавляются одной транзакцией: если хотя бы один пересекается "
                        + "с другим сеансом в зале, не добавится ни один."),
                dayRow, daySessions);
    }

    private VBox hallSection() {
        hallName.setPromptText("Название зала");
        Button add = new Button("Добавить зал");
        add.setOnAction(e -> addHall());
        GridPane g = grid();
        g.addRow(0, new Label("Название"), hallName, new Label("Перерыв, мин"), hallBreak);
        g.addRow(1, new Label("Рядов"), hallRows, new Label("Мест в ряду"), hallPerRow);
        g.add(add, 3, 2);
        return section("Новый зал", g, new Label("Места создаются автоматически (пакетная вставка JDBC)."));
    }

    private static GridPane grid() {
        GridPane g = new GridPane();
        g.setHgap(10);
        g.setVgap(8);
        return g;
    }

    private static VBox section(String title, javafx.scene.Node... nodes) {
        VBox box = new VBox(8);
        box.getChildren().add(Ui.header(title));
        box.getChildren().addAll(nodes);
        box.getStyleClass().add("panel");
        box.setPadding(new Insets(10));
        for (javafx.scene.Node n : nodes) if (n instanceof Label l) { l.setWrapText(true); l.getStyleClass().add("hint"); }
        return box;
    }

    void reload() {
        try {
            genreBox.getItems().setAll(catalog.genres().stream().map(Genre::name).toList());
            Movie m = movieBox.getValue();
            Hall h = hallBox.getValue();
            movieBox.getItems().setAll(catalog.movies());
            hallBox.getItems().setAll(catalog.halls());
            if (m != null) movieBox.getItems().stream().filter(x -> x.id() == m.id()).findFirst().ifPresent(movieBox::setValue);
            if (h != null) hallBox.getItems().stream().filter(x -> x.id() == h.id()).findFirst().ifPresent(hallBox::setValue);
            loadDay();
        } catch (BookingException e) {
            Ui.error("Загрузка справочников", e);
        }
    }

    private void loadDay() {
        try {
            daySessions.getItems().setAll(catalog.sessionsForDay(viewDay.getValue()));
        } catch (BookingException e) {
            Ui.error("Расписание", e);
        }
    }

    private void addMovie() {
        try {
            String genre = genreBox.getEditor().getText();
            Movie m = catalog.addMovie(titleField.getText(), genre,
                    Ui.parseInt(durationField.getText(), "Длительность"), ageBox.getValue(),
                    POSTERS.get(posterBox.getValue()));
            Ui.info("Фильм добавлен", m.title() + " (" + m.genre() + ", " + m.durationMin() + " мин.)");
            titleField.clear();
            durationField.clear();
            onChanged.run();
        } catch (BookingException e) {
            Ui.error("Добавление фильма", e);
        }
    }

    private void addSessions() {
        try {
            Movie m = movieBox.getValue();
            Hall h = hallBox.getValue();
            if (m == null || h == null) throw new BookingException("Выберите фильм и зал.");
            if (firstDay.getValue() == null) throw new BookingException("Выберите первый день.");
            LocalTime time;
            try {
                time = LocalTime.parse(timeField.getText().trim());
            } catch (DateTimeParseException ex) {
                throw new BookingException("Время в формате ЧЧ:ММ, например 19:30.");
            }
            int n = catalog.addSessions(m.id(), h.id(), firstDay.getValue(), Ui.parseInt(daysField.getText(), "Дней"),
                    time, Ui.parseMoney(priceField.getText(), "Цена"));
            Ui.info("Сеансы добавлены", "Добавлено сеансов: " + n);
            viewDay.setValue(firstDay.getValue());
            onChanged.run();
        } catch (BookingException e) {
            Ui.error("Добавление сеансов", e);
        }
    }

    private void deleteSession() {
        Session s = daySessions.getSelectionModel().getSelectedItem();
        if (s == null) { Ui.info("Удаление", "Выберите сеанс в списке."); return; }
        if (!Ui.confirm("Удаление сеанса", "Удалить сеанс «" + s.movieTitle() + "» " + s.startsAt().format(Session.FMT)
                + " (" + s.hallName() + ")?")) return;
        try {
            catalog.deleteSession(s.id());
            onChanged.run();
        } catch (BookingException e) {
            Ui.error("Удаление сеанса", e);
        }
    }

    private void addHall() {
        try {
            Hall h = catalog.addHall(hallName.getText(), Ui.parseInt(hallRows.getText(), "Рядов"),
                    Ui.parseInt(hallPerRow.getText(), "Мест в ряду"), Ui.parseInt(hallBreak.getText(), "Перерыв"));
            Ui.info("Зал добавлен", h.name() + ": " + h.seatCount() + " мест");
            hallName.clear();
            onChanged.run();
        } catch (BookingException e) {
            Ui.error("Добавление зала", e);
        }
    }
}
