package com.example.kinoshka.ui;

import com.example.kinoshka.model.ReportRow;
import com.example.kinoshka.repo.ReportRepository;
import com.example.kinoshka.repo.ReportRepository.Report;
import com.example.kinoshka.service.BookingException;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

import java.time.LocalDate;

/** Вкладка «Отчёты»: результаты агрегирующих запросов в таблице. */
class ReportsTab extends Tab {
    private static final String REVENUE = "Выручка по фильмам";
    private static final String OCCUPANCY = "Заполняемость сеансов за день";
    private static final String CUSTOMERS = "Покупатели";
    private static final String TICKETS = "Все проданные билеты";

    private final ReportRepository reports;
    private final ChoiceBox<String> kind = new ChoiceBox<>();
    private final DatePicker day = Ui.datePicker(LocalDate.now().plusDays(1));
    private final TableView<ReportRow> table = new TableView<>();
    private final Label summary = new Label();

    ReportsTab(ReportRepository reports) {
        super("Отчёты");
        this.reports = reports;
        setClosable(false);
        kind.getItems().addAll(REVENUE, OCCUPANCY, CUSTOMERS, TICKETS);
        kind.setValue(REVENUE);
        day.disableProperty().bind(kind.valueProperty().isNotEqualTo(OCCUPANCY));
        Button run = new Button("Сформировать");
        run.setOnAction(e -> run());
        HBox top = new HBox(8, new Label("Отчёт:"), kind, new Label("Дата:"), day, run);
        VBox root = new VBox(10, Ui.header("Отчёты"), top, table, summary);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setPadding(new Insets(12));
        setContent(root);
    }

    void run() {
        try {
            Report r = switch (kind.getValue()) {
                case OCCUPANCY -> reports.occupancy(day.getValue());
                case CUSTOMERS -> reports.customers();
                case TICKETS -> reports.tickets();
                default -> reports.revenueByMovie();
            };
            show(r);
            summary.setText(r.title() + ": строк — " + r.rows().size()
                    + " · общая выручка кинотеатра: " + reports.totalRevenue() + " ₽");
        } catch (BookingException e) {
            Ui.error("Отчёт", e);
        }
    }

    private void show(Report r) {
        table.getColumns().clear();
        for (int i = 0; i < r.headers().size(); i++) {
            final int idx = i;
            TableColumn<ReportRow, String> c = new TableColumn<>(r.headers().get(i));
            c.setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue().cells().get(idx)));
            // ширина делится поровну между столбцами и следует за шириной окна
            // (CONSTRAINED_RESIZE_POLICY при смене набора столбцов сжимал часть из них до нуля)
            c.prefWidthProperty().bind(table.widthProperty().subtract(20).divide(r.headers().size()));
            table.getColumns().add(c);
        }
        table.getItems().setAll(r.rows());
    }
}
