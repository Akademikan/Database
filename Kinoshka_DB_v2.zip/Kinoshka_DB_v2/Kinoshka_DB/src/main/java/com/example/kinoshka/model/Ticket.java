package com.example.kinoshka.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Проданный билет с данными для печати/отображения. */
public record Ticket(int id, int bookingId, String customerName, String movieTitle, String hallName,
                     LocalDateTime startsAt, int row, int seat, BigDecimal price) {
    @Override public String toString() {
        return "Билет №" + id + " | " + movieTitle + " | " + startsAt.format(Session.FMT) + " | " + hallName
                + " | ряд " + row + ", место " + seat + " | " + price + " ₽";
    }
}
