package com.example.kinoshka.model;

/** Жанр (таблица genres). */
public record Genre(int id, String name) {
    @Override public String toString() { return name; }
}
