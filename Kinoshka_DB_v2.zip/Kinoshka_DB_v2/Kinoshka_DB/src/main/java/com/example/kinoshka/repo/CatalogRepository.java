package com.example.kinoshka.repo;

import com.example.kinoshka.db.Database;
import com.example.kinoshka.model.Genre;
import com.example.kinoshka.model.Hall;
import com.example.kinoshka.model.Movie;
import com.example.kinoshka.model.Session;
import com.example.kinoshka.service.BookingException;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Справочная часть: жанры, фильмы, залы, сеансы (работа администратора). */
public class CatalogRepository {
    public static final String DEFAULT_POSTER = "/com/example/kinoshka/posters/default.png";

    private final Database db;

    public CatalogRepository(Database db) { this.db = db; }

    // ------------------------------------------------------------------ жанры и фильмы

    public List<Genre> genres() throws BookingException {
        return Jdbc.read(db, c -> {
            List<Genre> list = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement("SELECT genre_id, name FROM genres ORDER BY name");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(new Genre(rs.getInt(1), rs.getString(2)));
            }
            return list;
        });
    }

    public List<Movie> movies() throws BookingException {
        String sql = "SELECT m.movie_id, m.title, m.genre_id, g.name, m.duration_min, m.age_rating, m.poster_path "
                   + "FROM movies m JOIN genres g ON g.genre_id = m.genre_id ORDER BY m.title";
        return Jdbc.read(db, c -> {
            List<Movie> list = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(new Movie(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4),
                        rs.getInt(5), rs.getInt(6), rs.getString(7)));
            }
            return list;
        });
    }

    /**
     * Добавляет фильм. Если жанра с таким названием нет — он создаётся
     * в той же транзакции (либо добавятся и жанр, и фильм, либо ничего).
     */
    public Movie addMovie(String title, String genreName, int durationMin, int ageRating, String posterPath)
            throws BookingException {
        String t = title == null ? "" : title.trim();
        String g = genreName == null ? "" : genreName.trim();
        if (t.isEmpty()) throw new BookingException("Введите название фильма.");
        if (g.isEmpty()) throw new BookingException("Укажите жанр.");
        String poster = (posterPath == null || posterPath.isBlank()) ? DEFAULT_POSTER : posterPath;
        // Диапазоны проверяются и здесь (быстрый ответ пользователю), и в БД (CHECK) — БД главная.
        if (durationMin < 1 || durationMin > 600) throw new BookingException("Длительность: от 1 до 600 минут.");

        return Jdbc.inTransaction(db, c -> {
            int genreId = findGenre(c, g);
            if (genreId == 0)
                genreId = Jdbc.insertReturningId(c, "INSERT INTO genres (name) VALUES (?)", "genre_id", g);
            int id = Jdbc.insertReturningId(c,
                    "INSERT INTO movies (title, genre_id, duration_min, age_rating, poster_path) VALUES (?, ?, ?, ?, ?)",
                    "movie_id", t, genreId, durationMin, ageRating, poster);
            return new Movie(id, t, genreId, g, durationMin, ageRating, poster);
        });
    }

    private int findGenre(Connection c, String name) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT genre_id FROM genres WHERE LOWER(name) = LOWER(?)")) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    // ------------------------------------------------------------------ залы

    public List<Hall> halls() throws BookingException {
        String sql = "SELECT h.hall_id, h.name, h.break_minutes, COALESCE(MAX(s.row_no), 0), COUNT(s.seat_id) "
                   + "FROM halls h LEFT JOIN seats s ON s.hall_id = h.hall_id "
                   + "GROUP BY h.hall_id, h.name, h.break_minutes ORDER BY h.name";
        return Jdbc.read(db, c -> {
            List<Hall> list = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(new Hall(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getInt(5)));
            }
            return list;
        });
    }

    /** Создаёт зал и все его места одной транзакцией; места вставляются пакетом (JDBC batch). */
    public Hall addHall(String name, int rows, int seatsPerRow, int breakMinutes) throws BookingException {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) throw new BookingException("Введите название зала.");
        if (rows < 1 || rows > 50 || seatsPerRow < 1 || seatsPerRow > 60)
            throw new BookingException("Рядов: 1–50, мест в ряду: 1–60.");
        return Jdbc.inTransaction(db, c -> {
            int hallId = Jdbc.insertReturningId(c, "INSERT INTO halls (name, break_minutes) VALUES (?, ?)",
                    "hall_id", n, breakMinutes);
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO seats (hall_id, row_no, seat_no) VALUES (?, ?, ?)")) {
                for (int r = 1; r <= rows; r++) {
                    for (int s = 1; s <= seatsPerRow; s++) {
                        ps.setInt(1, hallId);
                        ps.setInt(2, r);
                        ps.setInt(3, s);
                        ps.addBatch();
                    }
                }
                ps.executeBatch();
            }
            return new Hall(hallId, n, breakMinutes, rows, rows * seatsPerRow);
        });
    }

    // ------------------------------------------------------------------ сеансы

    private static final String SESSION_SELECT =
        "SELECT s.session_id, m.movie_id, m.title, m.duration_min, h.hall_id, h.name, s.starts_at, s.base_price, "
      + "       (SELECT MAX(x.row_no) FROM seats x WHERE x.hall_id = h.hall_id) AS last_row, "
      + "       (SELECT COUNT(*) FROM tickets t WHERE t.session_id = s.session_id) AS sold, "
      + "       (SELECT COUNT(*) FROM seats x WHERE x.hall_id = h.hall_id) AS capacity "
      + "FROM sessions s JOIN movies m ON m.movie_id = s.movie_id JOIN halls h ON h.hall_id = s.hall_id ";

    /** Сеансы фильма в выбранный день. */
    public List<Session> sessionsForMovie(int movieId, LocalDate day) throws BookingException {
        return querySessions(SESSION_SELECT + "WHERE s.movie_id = ? AND s.starts_at >= ? AND s.starts_at < ? "
                + "ORDER BY s.starts_at, h.name", movieId, day.atStartOfDay(), day.plusDays(1).atStartOfDay());
    }

    /** Все сеансы дня (для администратора). */
    public List<Session> sessionsForDay(LocalDate day) throws BookingException {
        return querySessions(SESSION_SELECT + "WHERE s.starts_at >= ? AND s.starts_at < ? ORDER BY h.name, s.starts_at",
                day.atStartOfDay(), day.plusDays(1).atStartOfDay());
    }

    public Session session(int sessionId) throws BookingException {
        List<Session> list = querySessions(SESSION_SELECT + "WHERE s.session_id = ?", sessionId);
        if (list.isEmpty()) throw new BookingException("Сеанс №" + sessionId + " не найден.");
        return list.get(0);
    }

    private List<Session> querySessions(String sql, Object... params) throws BookingException {
        return Jdbc.read(db, c -> {
            List<Session> list = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                Jdbc.bind(ps, params);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) list.add(mapSession(rs));
                }
            }
            return list;
        });
    }

    static Session mapSession(ResultSet rs) throws SQLException {
        return new Session(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getString(6),
                Jdbc.dateTime(rs, "starts_at"), rs.getBigDecimal(8), rs.getInt(9), rs.getInt(10), rs.getInt(11));
    }

    /**
     * Добавляет сеанс на {@code days} дней подряд в одно и то же время.
     * Всё в одной транзакции: если хотя бы один день пересекается с другим
     * сеансом (триггер, KN002), не добавляется ни один.
     * @return количество добавленных сеансов
     */
    public int addSessions(int movieId, int hallId, LocalDate firstDay, int days, LocalTime time, BigDecimal price)
            throws BookingException {
        if (days < 1 || days > 31) throw new BookingException("Количество дней: от 1 до 31.");
        if (price == null || price.signum() <= 0) throw new BookingException("Цена должна быть больше нуля.");
        LocalDateTime first = firstDay.atTime(time);
        if (first.isBefore(LocalDateTime.now())) throw new BookingException("Нельзя создавать сеансы в прошлом.");
        return Jdbc.inTransaction(db, c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO sessions (movie_id, hall_id, starts_at, base_price) VALUES (?, ?, ?, ?)")) {
                for (int i = 0; i < days; i++) {
                    // по одной команде, а не пакетом: так ошибка триггера относится к конкретному дню
                    Jdbc.bind(ps, movieId, hallId, first.plusDays(i), price);
                    ps.executeUpdate();
                }
            }
            return days;
        });
    }

    /** Удаляет сеанс; если на него проданы билеты, БД запретит (FK RESTRICT). */
    public void deleteSession(int sessionId) throws BookingException {
        Jdbc.inTransaction(db, c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM sessions WHERE session_id = ?")) {
                ps.setInt(1, sessionId);
                if (ps.executeUpdate() == 0) throw new BookingException("Сеанс уже удалён.");
            }
            return null;
        });
    }
}
