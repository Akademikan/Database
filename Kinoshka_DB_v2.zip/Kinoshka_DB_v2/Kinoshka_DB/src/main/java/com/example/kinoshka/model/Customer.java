package com.example.kinoshka.model;

/** Покупатель (таблица customers). Телефон хранится в формате +79990000001. */
public record Customer(int id, String fullName, String phone, String email) { }
