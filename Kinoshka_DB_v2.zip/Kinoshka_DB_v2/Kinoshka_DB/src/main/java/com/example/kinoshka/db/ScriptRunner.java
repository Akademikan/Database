package com.example.kinoshka.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Выполнение SQL-скриптов через JDBC.
 *
 * JDBC выполняет по одной команде, поэтому скрипт нужно разбить на команды.
 * Простое разбиение по ';' не работает: точка с запятой встречается
 * в строках, комментариях, в телах функций PostgreSQL ($$ ... $$)
 * и в телах триггеров MySQL (там используется команда клиента DELIMITER).
 * Разборщик учитывает все эти случаи.
 */
public final class ScriptRunner {

    private ScriptRunner() { }

    /** Делит текст скрипта на отдельные команды (без завершающего разделителя). */
    public static List<String> split(String script, Dialect dialect) {
        List<String> result = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        String delimiter = ";";
        int i = 0;
        int n = script.length();
        boolean lineStart = true;

        while (i < n) {
            char c = script.charAt(i);

            // команда клиента MySQL: DELIMITER <новый разделитель> (только в начале строки)
            if (lineStart && cur.toString().isBlank() && startsWithIgnoreCase(script, i, "DELIMITER ")) {
                int eol = script.indexOf('\n', i);
                if (eol < 0) eol = n;
                delimiter = script.substring(i + "DELIMITER ".length(), eol).trim();
                if (delimiter.isEmpty()) throw new IllegalArgumentException("Пустой DELIMITER");
                cur.setLength(0);
                i = eol + 1;
                lineStart = true;
                continue;
            }
            lineStart = false;

            // однострочный комментарий
            if (c == '-' && i + 1 < n && script.charAt(i + 1) == '-') {
                int eol = script.indexOf('\n', i);
                i = eol < 0 ? n : eol;
                continue;
            }
            // многострочный комментарий
            if (c == '/' && i + 1 < n && script.charAt(i + 1) == '*') {
                int end = script.indexOf("*/", i + 2);
                i = end < 0 ? n : end + 2;
                continue;
            }
            // строковые литералы и идентификаторы в кавычках
            if (c == '\'' || c == '"' || c == '`') {
                int end = skipQuoted(script, i, c, dialect == Dialect.MYSQL);
                cur.append(script, i, end);
                i = end;
                continue;
            }
            // строки в долларовых кавычках PostgreSQL: $$...$$ или $tag$...$tag$
            if (c == '$' && dialect == Dialect.POSTGRESQL) {
                int tagEnd = dollarTagEnd(script, i);
                if (tagEnd > 0) {
                    String tag = script.substring(i, tagEnd + 1);
                    int close = script.indexOf(tag, tagEnd + 1);
                    int end = close < 0 ? n : close + tag.length();
                    cur.append(script, i, end);
                    i = end;
                    continue;
                }
            }
            // разделитель команд
            if (script.startsWith(delimiter, i)) {
                addIfNotBlank(result, cur);
                cur.setLength(0);
                i += delimiter.length();
                continue;
            }
            cur.append(c);
            if (c == '\n') lineStart = true;
            i++;
        }
        addIfNotBlank(result, cur);
        return result;
    }

    /** Выполняет скрипт в одном соединении; останавливается на первой ошибке. */
    public static int run(Connection connection, String script, Dialect dialect) throws SQLException {
        List<String> statements = split(script, dialect);
        try (Statement st = connection.createStatement()) {
            int k = 0;
            for (String sql : statements) {
                k++;
                try {
                    st.execute(sql);
                } catch (SQLException e) {
                    throw new SQLException("Ошибка в команде №" + k + ": " + e.getMessage()
                            + "\n---\n" + abbreviate(sql), e.getSQLState(), e.getErrorCode(), e);
                }
            }
        }
        return statements.size();
    }

    private static int skipQuoted(String s, int start, char quote, boolean backslashEscapes) {
        int i = start + 1;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (backslashEscapes && c == '\\' && quote != '`') { i += 2; continue; }
            if (c == quote) {
                if (i + 1 < s.length() && s.charAt(i + 1) == quote) { i += 2; continue; } // '' внутри строки
                return i + 1;
            }
            i++;
        }
        return s.length();
    }

    /** Если в позиции start начинается тег $...$, возвращает индекс закрывающего '$', иначе -1. */
    private static int dollarTagEnd(String s, int start) {
        int i = start + 1;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '$') return i;
            if (!(Character.isLetterOrDigit(c) || c == '_')) return -1;
            if (i == start + 1 && Character.isDigit(c)) return -1; // $1 — параметр, не тег
            i++;
        }
        return -1;
    }

    private static boolean startsWithIgnoreCase(String s, int pos, String prefix) {
        return s.regionMatches(true, pos, prefix, 0, prefix.length());
    }

    private static void addIfNotBlank(List<String> list, StringBuilder sb) {
        String sql = sb.toString().trim();
        if (!sql.isEmpty()) list.add(sql);
    }

    private static String abbreviate(String sql) {
        return sql.length() <= 300 ? sql : sql.substring(0, 300) + " ...";
    }
}
