package com.example.kinoshka.service;

import java.util.regex.Pattern;

/**
 * Приведение телефона к формату, который хранится в БД: '+' и 11–15 цифр.
 * Кассир может ввести «8 (999) 000-00-01» или «+7 999 000 00 01» — в базу
 * попадёт «+79990000001». Формат дополнительно проверяет CHECK chk_customers_phone.
 */
public final class PhoneUtil {
    private static final Pattern STORED = Pattern.compile("^\\+[0-9]{11,15}$");

    private PhoneUtil() { }

    public static String normalize(String input) throws BookingException {
        if (input == null || input.isBlank()) throw new BookingException("Укажите телефон покупателя.");
        String trimmed = input.trim();
        boolean plus = trimmed.startsWith("+");
        String digits = trimmed.replaceAll("[\\s()\\-.]", "");
        if (plus) digits = digits.substring(1);
        if (!digits.matches("[0-9]+"))
            throw new BookingException("Телефон может содержать только цифры, пробелы, скобки и дефисы: " + input);
        if (!plus && digits.length() == 11 && digits.startsWith("8")) digits = "7" + digits.substring(1);
        if (!plus && digits.length() == 10) digits = "7" + digits;          // 9990000001 -> +79990000001
        String result = "+" + digits;
        if (!STORED.matcher(result).matches())
            throw new BookingException("Неверный номер телефона: " + input + " (нужно 11–15 цифр)");
        return result;
    }
}
