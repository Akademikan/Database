package com.example.kinoshka.service;

import java.sql.SQLException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Перевод ошибок СУБД в сообщения для пользователя.
 *
 * Тексты ошибок PostgreSQL и MySQL различаются, но в обоих есть имя
 * нарушенного ограничения (uq_..., chk_..., fk_...), а пользовательские
 * ошибки триггеров имеют одинаковые SQLSTATE KN001–KN003. По ним и
 * определяется сообщение — так код не зависит от СУБД и языка сервера.
 */
public final class ErrorTranslator {
    private static final Pattern CONSTRAINT = Pattern.compile("\\b((?:uq|chk|fk|pk)_[a-z_]+)\\b");

    private static final Map<String, String> MESSAGES = Map.ofEntries(
        Map.entry("uq_genres_name",      "Такой жанр уже есть."),
        Map.entry("uq_movies_title",     "Фильм с таким названием уже есть."),
        Map.entry("chk_movies_duration", "Длительность фильма должна быть от 1 до 600 минут."),
        Map.entry("chk_movies_age",      "Возрастной рейтинг: 0, 6, 12, 16 или 18."),
        Map.entry("chk_movies_title",    "Название фильма не может быть пустым."),
        Map.entry("uq_halls_name",       "Зал с таким названием уже есть."),
        Map.entry("chk_halls_break",     "Перерыв между сеансами: от 0 до 120 минут."),
        Map.entry("uq_seats_place",      "Такое место в этом зале уже есть."),
        Map.entry("chk_seats_row",       "Номер ряда: от 1 до 50."),
        Map.entry("chk_seats_no",        "Номер места: от 1 до 60."),
        Map.entry("uq_sessions_slot",    "В этом зале на это время уже есть сеанс."),
        Map.entry("chk_sessions_price",  "Цена сеанса должна быть больше 0 и не больше 10 000."),
        Map.entry("uq_customers_phone",  "Покупатель с таким телефоном уже есть."),
        Map.entry("uq_customers_email",  "Этот e-mail уже указан у другого покупателя."),
        Map.entry("chk_customers_phone", "Неверный формат телефона."),
        Map.entry("chk_customers_email", "Неверный формат e-mail."),
        Map.entry("uq_tickets_sold",     "Одно из выбранных мест уже продано. Обновите схему зала."),
        Map.entry("chk_tickets_price",   "Цена билета должна быть положительной."),
        Map.entry("fk_movies_genre",     "Жанр используется в фильмах или не существует."),
        Map.entry("fk_sessions_movie",   "Фильм используется в сеансах или не существует."),
        Map.entry("fk_sessions_hall",    "Зал используется в сеансах или не существует."),
        Map.entry("fk_tickets_session",  "На сеанс проданы билеты — удалить его нельзя."),
        Map.entry("fk_tickets_seat",     "Место используется в проданных билетах."),
        Map.entry("fk_bookings_customer","У покупателя есть бронирования или он не существует.")
    );

    private ErrorTranslator() { }

    /** Возвращает понятное сообщение; если ошибка не распознана — исходный текст СУБД. */
    public static String message(SQLException e) {
        String state = e.getSQLState() == null ? "" : e.getSQLState();
        switch (state) {
            case "KN001": return "Место не принадлежит залу, в котором идёт сеанс.";
            case "KN002": return "Сеанс пересекается с другим сеансом в этом зале (с учётом длительности фильма и перерыва). "
                                 + detail(e);
            case "KN003": return "На сеанс уже проданы билеты — перенести его в другой зал нельзя.";
            default: break;
        }
        String text = e.getMessage() == null ? "" : e.getMessage();
        Matcher m = CONSTRAINT.matcher(text);
        while (m.find()) {
            String msg = MESSAGES.get(m.group(1));
            if (msg != null) return msg;
        }
        if (state.startsWith("08")) return "Нет соединения с сервером БД: " + text;
        return "Ошибка базы данных: " + text;
    }

    public static BookingException translate(SQLException e) {
        return new BookingException(message(e), e);
    }

    private static String detail(SQLException e) {
        String t = e.getMessage();
        if (t == null) return "";
        int p = t.indexOf("Сеанс пересекается");
        return p >= 0 ? "(" + t.substring(p).split("\\R")[0].trim() + ")" : "";
    }
}
