package com.example.kinoshka.model;

/** Место в зале и признак того, продано ли оно на выбранный сеанс. */
public record Seat(int id, int row, int number, boolean booked) {
    @Override public String toString() { return "ряд " + row + ", место " + number; }
}
