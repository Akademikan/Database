package com.example.kinoshka.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

/** Модульные тесты правила ценообразования (без БД). */
class PriceCalculatorTest {

    @ParameterizedTest(name = "база {0}, ряд {1} из {2} -> {3}")
    @CsvSource({
            "300, 1, 8, 270.00",   // передний ряд: 90 %
            "300, 2, 8, 270.00",
            "300, 3, 8, 300.00",   // обычный ряд
            "300, 7, 8, 300.00",
            "300, 8, 8, 345.00",   // последний ряд: 115 %
            "250, 5, 5, 287.50",
            "333.33, 8, 8, 383.33" // округление HALF_UP до копеек: 383.3295 -> 383.33
    })
    void priceByRow(String base, int row, int lastRow, String expected) {
        assertEquals(new BigDecimal(expected), PriceCalculator.price(new BigDecimal(base), row, lastRow));
    }

    @Test
    void smallHallFrontRowsHavePriority() {
        // в зале из двух рядов второй ряд одновременно «передний» и «последний» — действует скидка
        assertEquals(new BigDecimal("90.00"), PriceCalculator.price(new BigDecimal("100"), 2, 2));
    }

    @Test
    void rejectsInvalidArguments() {
        assertThrows(IllegalArgumentException.class, () -> PriceCalculator.price(BigDecimal.ZERO, 1, 5));
        assertThrows(IllegalArgumentException.class, () -> PriceCalculator.price(new BigDecimal("100"), 0, 5));
        assertThrows(IllegalArgumentException.class, () -> PriceCalculator.price(new BigDecimal("100"), 6, 5));
    }
}
