package com.example.kinoshka.db;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/** Порядок поиска файла настроек и переопределение пароля переменной окружения. */
class AppConfigTest {

    private static final String MYSQL_CFG = "db.type=mysql\nmysql.url=jdbc:mysql://h:3306/k\nmysql.user=u\nmysql.password=p\n";

    @Test
    void localConfigFileIsUsedAndReadAsUtf8(@TempDir Path dir) throws Exception {
        Files.createDirectories(dir.resolve("config"));
        Files.writeString(dir.resolve("config/db.properties"), "# комментарий по-русски\n" + MYSQL_CFG);
        AppConfig c = AppConfig.load(Map.of(), dir);
        assertEquals(Dialect.MYSQL, c.dialect());
        assertEquals("jdbc:mysql://h:3306/k", c.url());
        assertEquals("com.mysql.cj.jdbc.Driver", c.driver());
    }

    @Test
    void environmentVariablesOverrideFileAndPassword(@TempDir Path dir) throws Exception {
        Path other = dir.resolve("other.properties");
        Files.writeString(other, MYSQL_CFG);
        AppConfig c = AppConfig.load(Map.of(AppConfig.ENV_CONFIG, other.toString(), AppConfig.ENV_PASSWORD, "secret"), dir);
        assertEquals(other.toAbsolutePath().toString(), c.source());
        assertEquals("secret", c.password());
    }

    @Test
    void fallsBackToBuiltInDefaults(@TempDir Path emptyDir) throws Exception {
        AppConfig c = AppConfig.load(Map.of(), emptyDir);
        assertEquals("встроенный db.properties", c.source());
        assertEquals(Dialect.POSTGRESQL, c.dialect());
    }

    @Test
    void unknownDbTypeGivesClearError() {
        var p = new java.util.Properties();
        p.setProperty("db.type", "oracle");
        var c = AppConfig.fromProperties(p, "test");
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class, c::dialect);
        assertTrue(e.getMessage().contains("postgresql, mysql"));
    }
}
