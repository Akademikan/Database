package com.example.kinoshka.service;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

/** Модульные тесты нормализации телефона. */
class PhoneUtilTest {

    @ParameterizedTest
    @CsvSource({
            "'+79990000001',      +79990000001",
            "'8 (999) 000-00-01', +79990000001",
            "'+7 999 000 00 01',  +79990000001",
            "'79990000001',       +79990000001",
            "'9990000001',        +79990000001",
            "'+375291234567',     +375291234567"
    })
    void normalizes(String input, String expected) throws BookingException {
        assertEquals(expected, PhoneUtil.normalize(input));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "12345", "+7999abc0001", "8-999-000-0", "+1234567890123456"})
    void rejectsInvalid(String input) {
        assertThrows(BookingException.class, () -> PhoneUtil.normalize(input));
    }
}
