package com.example.kinoshka.service;

import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

/** Сообщения об ошибках одинаковы для текстов PostgreSQL и MySQL. */
class ErrorTranslatorTest {

    @Test
    void uniqueViolationPostgresAndMysqlGiveSameMessage() {
        SQLException pg = new SQLException(
                "ERROR: duplicate key value violates unique constraint \"uq_tickets_sold\"", "23505");
        SQLException my = new SQLException(
                "Duplicate entry '5-1' for key 'tickets.uq_tickets_sold'", "23000", 1062);
        assertEquals(ErrorTranslator.message(pg), ErrorTranslator.message(my));
        assertTrue(ErrorTranslator.message(pg).contains("уже продано"));
    }

    @Test
    void checkViolationIsRecognizedByConstraintName() {
        SQLException my = new SQLException("Check constraint 'chk_customers_phone' is violated.", "HY000", 3819);
        assertEquals("Неверный формат телефона.", ErrorTranslator.message(my));
    }

    @Test
    void triggerErrorsUseCustomSqlState() {
        assertTrue(ErrorTranslator.message(new SQLException("x", "KN001")).contains("не принадлежит залу"));
        assertTrue(ErrorTranslator.message(new SQLException("x", "KN002")).contains("пересекается"));
        assertTrue(ErrorTranslator.message(new SQLException("x", "KN003")).contains("перенести"));
    }

    @Test
    void unknownErrorKeepsOriginalText() {
        assertTrue(ErrorTranslator.message(new SQLException("something odd", "XX000")).contains("something odd"));
    }
}
