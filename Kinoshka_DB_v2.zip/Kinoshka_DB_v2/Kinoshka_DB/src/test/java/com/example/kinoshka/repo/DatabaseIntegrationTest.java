package com.example.kinoshka.repo;

import com.example.kinoshka.db.AppConfig;
import com.example.kinoshka.db.Database;
import com.example.kinoshka.db.DbInstaller;
import com.example.kinoshka.model.BookingInfo;
import com.example.kinoshka.model.Hall;
import com.example.kinoshka.model.Movie;
import com.example.kinoshka.model.Seat;
import com.example.kinoshka.model.Session;
import com.example.kinoshka.model.Ticket;
import com.example.kinoshka.service.BookingException;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

/**
 * Интеграционные тесты приложения и БД. Каждый тест выполняется для каждой
 * настроенной СУБД; перед тестом база пересоздаётся скриптами из database/.
 *
 * Запуск: переменная окружения KINOSHKA_IT_CONFIGS со списком файлов настроек
 * через запятую, например
 * {@code KINOSHKA_IT_CONFIGS=config/test-pg.properties,config/test-mysql.properties mvn test}.
 * Без переменной тесты пропускаются (обычная сборка не требует запущенных СУБД).
 *
 * ВНИМАНИЕ: тесты удаляют все данные в указанных базах — используйте отдельные тестовые базы.
 */
class DatabaseIntegrationTest {

    static Stream<String> configs() {
        String v = System.getenv("KINOSHKA_IT_CONFIGS");
        if (v == null || v.isBlank()) return Stream.of("SKIP");
        return Arrays.stream(v.split(",")).map(String::trim).filter(s -> !s.isEmpty());
    }

    private Database db;
    private CatalogRepository catalog;
    private BookingRepository bookings;
    private ReportRepository reports;

    private void fresh(String configPath) throws Exception {
        assumeTrue(!"SKIP".equals(configPath), "KINOSHKA_IT_CONFIGS не задана — интеграционные тесты пропущены");
        db = new Database(AppConfig.fromFile(Path.of(configPath)));
        DbInstaller.install(db, true);
        catalog = new CatalogRepository(db);
        bookings = new BookingRepository(db);
        reports = new ReportRepository(db);
    }

    /** Ближайший сеанс завтрашнего дня, у которого есть свободные места в ряду 3. */
    private Session tomorrowSession() throws BookingException {
        List<Session> list = catalog.sessionsForDay(LocalDate.now().plusDays(1));
        assertFalse(list.isEmpty(), "в тестовых данных должны быть сеансы на завтра");
        return list.get(list.size() - 1);
    }

    private List<Seat> freeSeats(Session s, int count) throws BookingException {
        List<Seat> free = bookings.seatsForSession(s.id()).stream().filter(x -> !x.booked()).toList();
        assertTrue(free.size() >= count);
        return free.subList(0, count);
    }

    private int countTickets(String where, Object... params) throws SQLException {
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM tickets WHERE " + where)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1); }
        }
    }

    // ---------------------------------------------------------------- тестовые данные

    @ParameterizedTest(name = "[{0}] в каждой таблице не менее 5 строк")
    @MethodSource("configs")
    void seedDataHasAtLeastFiveRowsPerTable(String cfg) throws Exception {
        fresh(cfg);
        try (Connection c = db.getConnection()) {
            for (String t : List.of("genres", "movies", "halls", "seats", "sessions", "customers", "bookings", "tickets")) {
                try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM " + t);
                     ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    assertTrue(rs.getInt(1) >= 5, t + ": " + rs.getInt(1));
                }
            }
        }
        assertEquals(8, catalog.movies().size());
        assertEquals(new BigDecimal("5162.50"), reports.totalRevenue().setScale(2));
    }

    // ---------------------------------------------------------------- бронирование

    @ParameterizedTest(name = "[{0}] бронирование нескольких мест и цены по рядам")
    @MethodSource("configs")
    void bookingCreatesTicketsWithRowPrices(String cfg) throws Exception {
        fresh(cfg);
        Session s = tomorrowSession();
        List<Seat> seats = bookings.seatsForSession(s.id());
        Seat front = seats.stream().filter(x -> x.row() == 1 && !x.booked()).findFirst().orElseThrow();
        Seat last = seats.stream().filter(x -> x.row() == s.lastRow() && !x.booked()).findFirst().orElseThrow();

        List<Ticket> t = bookings.book(s.id(), List.of(front.id(), last.id()), "Тест Тестов", "8 (900) 111-22-33", null);

        assertEquals(2, t.size());
        assertEquals(s.basePrice().multiply(new BigDecimal("0.90")).setScale(2), t.get(0).price());
        assertEquals(s.basePrice().multiply(new BigDecimal("1.15")).setScale(2, java.math.RoundingMode.HALF_UP), t.get(1).price());
        assertTrue(bookings.seatsForSession(s.id()).stream().filter(x -> x.id() == front.id()).findFirst().orElseThrow().booked());
        assertEquals("+79001112233", bookings.findCustomer("+79001112233").orElseThrow().phone());
    }

    @ParameterizedTest(name = "[{0}] одно место нельзя продать дважды, бронирование атомарно")
    @MethodSource("configs")
    void doubleBookingIsRejectedAndNothingIsSavedPartially(String cfg) throws Exception {
        fresh(cfg);
        Session s = tomorrowSession();
        List<Seat> two = freeSeats(s, 2);
        bookings.book(s.id(), List.of(two.get(0).id()), "Первый", "+79001110001", null);
        int before = countTickets("session_id = ?", s.id());

        // второе бронирование: свободное место + уже проданное -> не должно сохраниться ничего
        BookingException e = assertThrows(BookingException.class, () ->
                bookings.book(s.id(), List.of(two.get(1).id(), two.get(0).id()), "Второй", "+79001110002", null));
        assertTrue(e.getMessage().contains("уже продано"), e.getMessage());
        assertEquals(before, countTickets("session_id = ?", s.id()), "частичной продажи быть не должно");
        assertTrue(bookings.findCustomer("+79001110002").isEmpty(), "новый покупатель тоже откатывается");
    }

    @ParameterizedTest(name = "[{0}] два кассира одновременно продают одно место")
    @MethodSource("configs")
    void concurrentBookingOfSameSeatHasExactlyOneWinner(String cfg) throws Exception {
        fresh(cfg);
        Session s = tomorrowSession();
        int seatId = freeSeats(s, 1).get(0).id();
        int threads = 4;
        CountDownLatch start = new CountDownLatch(1);
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        List<Future<Boolean>> results = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            String phone = "+7900222000" + i;
            results.add(pool.submit(() -> {
                start.await();
                try {
                    bookings.book(s.id(), List.of(seatId), "Кассир", phone, null);
                    return true;
                } catch (BookingException ex) {
                    return false;
                }
            }));
        }
        start.countDown();
        int ok = 0;
        for (Future<Boolean> f : results) if (f.get()) ok++;
        pool.shutdown();
        assertEquals(1, ok, "место должен получить ровно один покупатель");
        assertEquals(1, countTickets("session_id = ? AND seat_id = ?", s.id(), seatId));
    }

    @ParameterizedTest(name = "[{0}] нельзя продать билет на начавшийся сеанс")
    @MethodSource("configs")
    void cannotBookStartedSession(String cfg) throws Exception {
        fresh(cfg);
        Hall hall = catalog.addHall("Тестовый зал", 2, 3, 10);
        int sessionId;
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "INSERT INTO sessions (movie_id, hall_id, starts_at, base_price) VALUES (?, ?, ?, ?)",
                     new String[]{"session_id"})) {
            ps.setInt(1, catalog.movies().get(0).id());
            ps.setInt(2, hall.id());
            ps.setObject(3, LocalDateTime.now().minusMinutes(10).withNano(0));
            ps.setBigDecimal(4, new BigDecimal("300"));
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { rs.next(); sessionId = rs.getInt(1); }
        }
        int seat = bookings.seatsForSession(sessionId).get(0).id();
        BookingException e = assertThrows(BookingException.class,
                () -> bookings.book(sessionId, List.of(seat), "Опоздавший", "+79003330001", null));
        assertTrue(e.getMessage().contains("начался"));
    }

    @ParameterizedTest(name = "[{0}] отмена бронирования освобождает места (каскадное удаление)")
    @MethodSource("configs")
    void cancelBookingFreesSeats(String cfg) throws Exception {
        fresh(cfg);
        Session s = tomorrowSession();
        List<Seat> seats = freeSeats(s, 3);
        List<Ticket> t = bookings.book(s.id(), seats.stream().map(Seat::id).toList(), "Возврат", "+79004440001", null);
        List<BookingInfo> mine = bookings.bookingsByPhone("+79004440001");
        assertEquals(1, mine.size());
        assertEquals(3, mine.get(0).ticketCount());
        assertTrue(mine.get(0).seats().startsWith("р"));

        assertEquals(3, bookings.cancelBooking(t.get(0).bookingId()));
        assertEquals(0, countTickets("booking_id = ?", t.get(0).bookingId()));
        assertTrue(bookings.bookingsByPhone("+79004440001").isEmpty());
    }

    // ---------------------------------------------------------------- ограничения и триггеры

    @ParameterizedTest(name = "[{0}] триггер: место из другого зала (KN001)")
    @MethodSource("configs")
    void seatFromAnotherHallIsRejectedByTrigger(String cfg) throws Exception {
        fresh(cfg);
        Session s = tomorrowSession();
        Hall other = catalog.halls().stream().filter(h -> h.id() != s.hallId()).findFirst().orElseThrow();
        int foreignSeat;
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT MIN(seat_id) FROM seats WHERE hall_id = ?")) {
            ps.setInt(1, other.id());
            try (ResultSet rs = ps.executeQuery()) { rs.next(); foreignSeat = rs.getInt(1); }
        }
        BookingException e = assertThrows(BookingException.class,
                () -> bookings.book(s.id(), List.of(foreignSeat), "Хитрец", "+79005550001", null));
        assertTrue(e.getMessage().contains("не принадлежит залу"), e.getMessage());
    }

    @ParameterizedTest(name = "[{0}] триггер: пересечение сеансов (KN002), добавление серии атомарно")
    @MethodSource("configs")
    void overlappingSessionsAreRejectedAndSeriesIsAtomic(String cfg) throws Exception {
        fresh(cfg);
        Hall hall = catalog.halls().stream().filter(h -> h.name().equals("Зал 1")).findFirst().orElseThrow();
        Movie movie = catalog.movies().stream().filter(m -> m.title().equals("Интерстеллар")).findFirst().orElseThrow();
        LocalDate day = LocalDate.now().plusDays(1);
        int before = catalog.sessionsForDay(day).size() + catalog.sessionsForDay(day.plusDays(1)).size();

        // 11:00 — внутри сеанса 10:00 того же зала (тестовые данные), серия на 2 дня не добавится целиком
        BookingException e = assertThrows(BookingException.class, () ->
                catalog.addSessions(movie.id(), hall.id(), day, 2, LocalTime.of(11, 0), new BigDecimal("300")));
        assertTrue(e.getMessage().contains("пересекается"), e.getMessage());
        assertEquals(before, catalog.sessionsForDay(day).size() + catalog.sessionsForDay(day.plusDays(1)).size());

        // ночной сеанс после последнего (20:30 + 169 мин + 15 мин = 23:34) — допустим
        assertEquals(2, catalog.addSessions(movie.id(), hall.id(), day, 2, LocalTime.of(23, 40), new BigDecimal("280")));
    }

    @ParameterizedTest(name = "[{0}] UNIQUE и CHECK дают понятные сообщения")
    @MethodSource("configs")
    void constraintViolationsAreTranslated(String cfg) throws Exception {
        fresh(cfg);
        BookingException dup = assertThrows(BookingException.class,
                () -> catalog.addMovie("Интерстеллар", "Фантастика", 100, 12, null));
        assertEquals("Фильм с таким названием уже есть.", dup.getMessage());

        BookingException age = assertThrows(BookingException.class,
                () -> catalog.addMovie("Новый фильм", "Документальный", 90, 14, null));
        assertEquals("Возрастной рейтинг: 0, 6, 12, 16 или 18.", age.getMessage());
        // жанр «Документальный» создавался в той же транзакции и должен откатиться
        assertTrue(catalog.genres().stream().noneMatch(g -> g.name().equals("Документальный")));

        BookingException hall = assertThrows(BookingException.class, () -> catalog.addHall("Зал 1", 3, 3, 10));
        assertEquals("Зал с таким названием уже есть.", hall.getMessage());
    }

    @ParameterizedTest(name = "[{0}] нельзя удалить сеанс с проданными билетами (FK RESTRICT)")
    @MethodSource("configs")
    void sessionWithTicketsCannotBeDeleted(String cfg) throws Exception {
        fresh(cfg);
        Session sold = catalog.sessionsForDay(LocalDate.now().plusDays(1)).stream()
                .filter(x -> x.soldCount() > 0).findFirst().orElseThrow();
        BookingException e = assertThrows(BookingException.class, () -> catalog.deleteSession(sold.id()));
        assertTrue(e.getMessage().contains("проданы билеты"), e.getMessage());
    }

    // ---------------------------------------------------------------- администрирование и отчёты

    @ParameterizedTest(name = "[{0}] новый фильм, зал (batch) и сеанс")
    @MethodSource("configs")
    void adminAddsMovieHallAndSession(String cfg) throws Exception {
        fresh(cfg);
        Movie m = catalog.addMovie("Тестовый фильм", "Документальный", 77, 6, null);
        assertTrue(catalog.genres().stream().anyMatch(g -> g.name().equals("Документальный")));
        Hall h = catalog.addHall("Зал 7", 7, 9, 5);
        Hall reloaded = catalog.halls().stream().filter(x -> x.id() == h.id()).findFirst().orElseThrow();
        assertEquals(63, reloaded.seatCount());
        assertEquals(7, reloaded.rowCount());
        LocalDate day = LocalDate.now().plusDays(3);
        assertEquals(1, catalog.addSessions(m.id(), h.id(), day, 1, LocalTime.of(12, 0), new BigDecimal("199.90")));
        Session s = catalog.sessionsForMovie(m.id(), day).get(0);
        assertEquals(new BigDecimal("199.90"), s.basePrice());
        assertEquals(LocalTime.of(12, 0), s.startsAt().toLocalTime());   // время не сдвинулось часовым поясом
        assertEquals(63, s.seatCount());
    }

    @ParameterizedTest(name = "[{0}] отчёты согласованы с данными")
    @MethodSource("configs")
    void reportsAreConsistent(String cfg) throws Exception {
        fresh(cfg);
        ReportRepository.Report revenue = reports.revenueByMovie();
        assertEquals(8, revenue.rows().size(), "LEFT JOIN: в отчёте все фильмы, даже без продаж");
        BigDecimal sum = revenue.rows().stream().map(r -> new BigDecimal(r.cells().get(4))).reduce(BigDecimal.ZERO, BigDecimal::add);
        assertEquals(0, sum.compareTo(reports.totalRevenue()));
        assertEquals(18, reports.tickets().rows().size());
        assertEquals(6, reports.customers().rows().size());
        assertFalse(reports.occupancy(LocalDate.now().plusDays(1)).rows().isEmpty());
    }
}
