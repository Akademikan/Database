package com.example.kinoshka.db;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Разбор SQL-скриптов на команды. */
class ScriptRunnerTest {

    @Test
    void splitsSimpleStatementsAndSkipsComments() {
        String sql = "-- комментарий; с точкой с запятой\nCREATE TABLE a (x INT);\n/* блок; */ INSERT INTO a VALUES (1);\n";
        List<String> st = ScriptRunner.split(sql, Dialect.POSTGRESQL);
        assertEquals(List.of("CREATE TABLE a (x INT)", "INSERT INTO a VALUES (1)"), st);
    }

    @Test
    void keepsSemicolonsInsideStrings() {
        List<String> st = ScriptRunner.split("INSERT INTO t VALUES ('a;b', 'it''s; ok');SELECT 1;", Dialect.MYSQL);
        assertEquals(2, st.size());
        assertEquals("INSERT INTO t VALUES ('a;b', 'it''s; ok')", st.get(0));
    }

    @Test
    void postgresDollarQuotedFunctionBodyIsOneStatement() {
        String sql = "CREATE FUNCTION f() RETURNS trigger AS $$\nBEGIN\n  RAISE NOTICE 'x;y';\n  RETURN NEW;\nEND;\n$$ LANGUAGE plpgsql;\n"
                   + "CREATE TRIGGER t BEFORE INSERT ON a FOR EACH ROW EXECUTE FUNCTION f();";
        List<String> st = ScriptRunner.split(sql, Dialect.POSTGRESQL);
        assertEquals(2, st.size());
        assertTrue(st.get(0).endsWith("$$ LANGUAGE plpgsql"));
    }

    @Test
    void mysqlDelimiterCommandIsHonoured() {
        String sql = "DROP PROCEDURE IF EXISTS p;\nDELIMITER $$\nCREATE PROCEDURE p()\nBEGIN\n  SELECT 1;\n  SELECT 2;\nEND$$\n"
                   + "CREATE TRIGGER t BEFORE INSERT ON a FOR EACH ROW\nBEGIN\n  CALL p();\nEND$$\nDELIMITER ;\nSELECT 3;";
        List<String> st = ScriptRunner.split(sql, Dialect.MYSQL);
        assertEquals(4, st.size(), st.toString());
        assertTrue(st.get(1).startsWith("CREATE PROCEDURE p()"));
        assertTrue(st.get(1).contains("SELECT 2;"));
        assertEquals("SELECT 3", st.get(3));
    }

    @Test
    void projectScriptsSplitWithoutLosingStatements() throws Exception {
        // реальные скрипты проекта: количество команд проверено запуском на PostgreSQL 16 и MySQL 8.0
        assertEquals(23, ScriptRunner.split(DbInstaller.readScript(Dialect.POSTGRESQL, "01_schema.sql"), Dialect.POSTGRESQL).size());
        assertEquals(4, ScriptRunner.split(DbInstaller.readScript(Dialect.POSTGRESQL, "02_triggers.sql"), Dialect.POSTGRESQL).size());
        assertEquals(8, ScriptRunner.split(DbInstaller.readScript(Dialect.MYSQL, "02_triggers.sql"), Dialect.MYSQL).size());
    }
}
