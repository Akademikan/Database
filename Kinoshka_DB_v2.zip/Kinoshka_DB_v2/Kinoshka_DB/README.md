# Kinoshka DB — информационная система кинотеатра

Итоговый проект по курсам «Базы данных» и «Системный подход в разработке ПО».
Java-приложение с графическим интерфейсом (JavaFX) для продажи билетов в кинотеатр.
Работает с **PostgreSQL** и **MySQL** через **JDBC** без ORM и фреймворков;
СУБД выбирается в файле настроек.

![Касса](docs/img/cashier.png)

## Возможности

| Роль | Что делает |
|---|---|
| Кассир (вкладка «Касса») | выбирает дату, фильм, сеанс; видит схему зала со свободными и проданными местами; оформляет бронирование нескольких мест; постоянный покупатель находится по телефону |
| Кассир (вкладка «Бронирования») | находит бронирования по телефону, отменяет бронирование (возврат) до начала сеанса |
| Администратор | добавляет фильмы (новый жанр создаётся автоматически), сеансы сразу на несколько дней, залы (места генерируются автоматически), удаляет сеансы без проданных билетов |
| Администратор (вкладка «Отчёты») | выручка по фильмам, заполняемость сеансов за день, покупатели, все проданные билеты |

Главные правила обеспечивает **база данных**, а не только приложение:

- место нельзя продать дважды (UNIQUE);
- место должно быть из зала, где идёт сеанс (триггер);
- сеансы в одном зале не пересекаются с учётом длительности фильма и перерыва на уборку (триггер);
- форматы телефона, e-mail, диапазоны цен и длительностей проверяются CHECK-ограничениями.

Подробно — в [docs/01_domain.md](docs/01_domain.md).

## Структура репозитория

```text
├── database/
│   ├── postgresql/   00_create_db_user.sql  01_schema.sql  02_triggers.sql  03_data.sql  04_constraint_tests.sql
│   └── mysql/        те же файлы для MySQL 8
├── config/db.properties.example   образец файла настроек
├── src/main/java/com/example/kinoshka/
│   ├── Launcher.java              точка входа (GUI, --init-db, --check)
│   ├── db/        AppConfig, Database, Dialect, ScriptRunner, DbInstaller
│   ├── repo/      CatalogRepository, BookingRepository, ReportRepository (весь SQL здесь)
│   ├── service/   PriceCalculator, PhoneUtil, ErrorTranslator, BookingException
│   ├── model/     Movie, Session, Seat, Hall, Ticket, ... (record-классы)
│   └── ui/        MainApp и вкладки интерфейса
├── src/test/java/                 модульные и интеграционные тесты (JUnit 5)
├── docs/                          описание, модель БД и НФБК, план тестирования, Git, черновик отчёта
├── run.sh / run.bat               запуск в Linux / Windows
└── pom.xml                        сборка Maven (есть Maven Wrapper: mvnw / mvnw.cmd)
```

## Развёртывание

### 1. Что нужно установить

- **JDK 21.** Maven ставить не обязательно: в проекте есть Maven Wrapper (`mvnw`), он сам скачает Maven и зависимости (нужен интернет при первой сборке).
- **СУБД:** PostgreSQL 14+ и/или MySQL 8.0.16+.

### 2. Создать базу и пользователя (один раз, под администратором СУБД)

**PostgreSQL:**

```bash
psql -U postgres -f database/postgresql/00_create_db_user.sql
```

**MySQL** (выполнить под `root`):

```bash
mysql -u root -p < database/mysql/00_create_db_user.sql
```

Скрипт создаёт базу `kinoshka` и пользователя `kino` с паролем `kino`. Для MySQL он также разрешает создание триггеров обычным пользователем: без этого MySQL 8 с включённым двоичным журналом выдаёт ошибку 1419. Подробности — в [docs/03_dbms_differences.md](docs/03_dbms_differences.md).

### 3. Настроить подключение

```bash
cp config/db.properties.example config/db.properties      # Windows: copy config\db.properties.example config\db.properties
```

В `config/db.properties` укажите `db.type=postgresql` или `db.type=mysql`, а также адрес, пользователя и пароль.

- Файл `config/db.properties` исключён из Git, поэтому пароль не попадёт в репозиторий.
- Пароль можно не писать в файл, а задать переменной окружения `KINOSHKA_DB_PASSWORD`.
- Другой путь к файлу задаётся так: `java -Dkinoshka.config=путь …` или переменной `KINOSHKA_CONFIG`.

### 4. Создать таблицы и тестовые данные

**Вариант А — средствами приложения** (одинаково для обеих СУБД; скрипты выполняются через JDBC):

```bash
./run.sh --init-db          # Linux / macOS
run.bat --init-db           # Windows
```

**Вариант Б — вручную** клиентом СУБД, файлы `01_schema.sql`, `02_triggers.sql`, `03_data.sql` по порядку:

```bash
psql -U kino -d kinoshka -f database/postgresql/01_schema.sql -f database/postgresql/02_triggers.sql -f database/postgresql/03_data.sql
mysql -u kino -p kinoshka < database/mysql/01_schema.sql      # затем 02_triggers.sql и 03_data.sql
```

В DBeaver скрипты выполняйте целиком: Alt+X, «Execute SQL Script».

Тестовые данные — расписание на 7 дней **от текущей даты**, поэтому сеансы есть в любой день запуска. Повторный запуск `--init-db` пересоздаёт базу с нуля.

### 5. Запуск

```bash
./run.sh            # Linux / macOS
run.bat             # Windows (двойной щелчок тоже работает)
```

Первый запуск собирает `target/kinoshka-db-1.0-all.jar`. Альтернативы:

- `./mvnw javafx:run` (Windows: `mvnw.cmd javafx:run`);
- запуск класса `com.example.kinoshka.Launcher` из IDE.

В строке состояния внизу окна видно, к какой СУБД подключено приложение и какой файл настроек использован.

### Особенности ОС

| | Windows | Linux |
|---|---|---|
| Скрипт запуска | `run.bat` (переводы строк CRLF, `chcp 65001` для UTF-8 в консоли) | `run.sh` (LF; при необходимости `chmod +x run.sh mvnw`) |
| Кодировка консоли | по умолчанию CP866 → без `chcp 65001` кириллица в выводе `--init-db` искажается | при локали POSIX кириллица выводится как `?` → в скрипте задано `-Dstdout.encoding=UTF-8` |
| Файл настроек | читается в UTF-8 на обеих ОС; путь `config\db.properties` или `config/db.properties` | |
| Сборка jar | JavaFX содержит машинный код: `-all.jar` работает только на ОС, где собран. На второй ОС соберите заново (`run` сделает это сам) | |
| Формат даты | приложение всегда показывает `дд.мм.гггг`, независимо от языка ОС | |

`.gitattributes` фиксирует переводы строк: при клонировании на любой ОС скрипты не ломаются.

## Тесты

```bash
./mvnw test                     # модульные тесты (БД не нужна)
```

Интеграционные тесты проверяют каждое правило на настоящей СУБД. Им нужны отдельные тестовые базы — тест пересоздаёт базу:

```bash
# в файлах — настройки тестовых баз; можно указать обе СУБД сразу
KINOSHKA_IT_CONFIGS=config/test-pg.properties,config/test-mysql.properties ./mvnw test
```

Ручная проверка ограничений: скрипты `04_constraint_tests.sql`, в них каждая команда должна завершиться ошибкой.

План и результаты тестирования — в [docs/04_test_plan.md](docs/04_test_plan.md).

## Документация

- [docs/01_domain.md](docs/01_domain.md) — предметная область, роли, бизнес-правила, функции приложения.
- [docs/02_model.md](docs/02_model.md) — логическая и реляционная модели, типы данных, ограничения, доказательство НФБК.
- [docs/03_dbms_differences.md](docs/03_dbms_differences.md) — чем отличаются версии для PostgreSQL и MySQL.
- [docs/04_test_plan.md](docs/04_test_plan.md) — план тестирования и результаты.
- [docs/05_git_and_review.md](docs/05_git_and_review.md) — работа с ветками и инструкция для одногруппника-тестировщика.
- [docs/06_report_outline.md](docs/06_report_outline.md) — структура итогового отчёта.
